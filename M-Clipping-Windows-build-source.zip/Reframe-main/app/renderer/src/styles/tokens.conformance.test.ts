// tokens.conformance.test.ts — design-system one-accent discipline guard (WU A6).
//
// tokens.css states the rule of use: "Consume tokens only — no one-off hex values
// in component CSS." The usage panel's animated "superpowered / high-headroom"
// state historically shipped ad-hoc purple hex (#9b6cff / rgba(155,108,255,…) /
// #c2a3ff) baked straight into usageBar.css — an accent OFF the single-accent
// amber + RYG status ladder, undocumented as a token.
//
// These tests assert the reconcile:
//   1. usageBar.css carries NO raw color literals — every color routes through a
//      token custom property (var(--…)); and
//   2. the one sanctioned off-ladder exception (the "abundance" hue) is a
//      DOCUMENTED semantic token in tokens.css, not an ad-hoc component value.
//
// This file imports no TS source; it is a pure style-file conformance check and
// is excluded from the renderer coverage scope (styles are .css, not .ts/.tsx).

import { readFileSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join, relative } from 'node:path';

import { describe, it, expect } from 'vitest';

const HERE = dirname(fileURLToPath(import.meta.url));
const TOKENS_CSS = resolve(HERE, 'tokens.css');
const USAGE_BAR_CSS = resolve(HERE, '..', 'components', 'usageBar.css');
// Component sheets the WU-D1 TYPE/WEIGHT/CONTROL scale routes through.
const SHELL_CSS = resolve(HERE, '..', 'components', 'shell.css');
const TOPTAB_CSS = resolve(HERE, '..', 'components', 'topTabBar.css');
const LIB_CARDS_CSS = resolve(HERE, '..', 'components', 'library-cards.css');

/** Every raw color literal in a stylesheet: #rgb/#rrggbb(/aa) and rgb()/rgba(). */
const RAW_COLOR = /#[0-9a-fA-F]{3,8}\b|\brgba?\(/g;

/** Strip `/* … *\/` comment blocks so documentation prose never trips the scan. */
function stripComments(css: string): string {
  return css.replace(/\/\*[\s\S]*?\*\//g, '');
}

describe('design-system one-accent discipline (WU A6)', () => {
  it('usageBar.css uses NO raw color literals — colors route through tokens only', () => {
    const css = stripComments(readFileSync(USAGE_BAR_CSS, 'utf8'));
    const leaks = css.match(RAW_COLOR) ?? [];
    expect(leaks).toEqual([]);
  });

  it('usageBar.css consumes the documented abundance token for the superpowered state', () => {
    const css = readFileSync(USAGE_BAR_CSS, 'utf8');
    // The border + wash + label of the superpowered group all go through the token.
    expect(css).toMatch(/var\(--status-abundance\)/);
    expect(css).toMatch(/var\(--status-abundance-soft\)/);
    expect(css).toMatch(/var\(--status-abundance-text\)/);
  });

  it('tokens.css DOCUMENTS the abundance hue as the single sanctioned off-ladder token', () => {
    const css = readFileSync(TOKENS_CSS, 'utf8');
    // The token family is defined (base / soft / text) alongside the RYG statuses…
    expect(css).toMatch(/--status-abundance:\s*#[0-9a-fA-F]{3,8}/);
    expect(css).toMatch(/--status-abundance-soft:\s*rgba?\(/);
    expect(css).toMatch(/--status-abundance-text:\s*#[0-9a-fA-F]{3,8}/);
    // …and is explicitly documented as the ONE exception to one-accent discipline.
    const doc = css.toLowerCase();
    expect(doc).toContain('abundance');
    expect(doc).toContain('exception');
  });
});

// --- WU-2a: dark-editorial surface-ladder recalibration guard --------------------
//
// The pain these tests pin: the ladder used to sit only ~4-6 luminance points apart
// on pure near-black, so a card, a panel and a media well merged into one flat
// plane ("feels like 1.1 / didn't see changes"). This block re-derives the WCAG
// relative-luminance + contrast math INDEPENDENTLY of tokens.css and asserts, as a
// REAL regression guard (not a value echo), that the recalibrated ladder is:
//   1. LIFTED off pure near-black,
//   2. COOL blue-gray (locked mood — blue channel dominant),
//   3. WIDENED into visibly distinct planes (minimum rung gaps), and
//   4. still AA for the faint text step (>=4.5:1) on every elevation plane.
// If anyone flattens the ladder back toward near-black, or warms/greys the tint,
// or drops faint below AA, these fail.

/** Parse every `--name: value;` custom property from tokens.css into a map. */
function readTokens(): Map<string, string> {
  const css = readFileSync(TOKENS_CSS, 'utf8');
  const map = new Map<string, string>();
  const decl = /(--[\w-]+):\s*([^;]+);/g;
  for (let m = decl.exec(css); m !== null; m = decl.exec(css)) {
    map.set(m[1], m[2].trim());
  }
  return map;
}

type Rgb = readonly [number, number, number];

/** #rrggbb -> [r, g, b] (0-255). Throws if the token is not a plain hex. */
function toRgb(tokens: Map<string, string>, name: string): Rgb {
  const raw = tokens.get(name);
  if (raw === undefined) throw new Error(`missing token ${name}`);
  const hex = /^#([0-9a-fA-F]{6})$/.exec(raw);
  if (hex === null) throw new Error(`token ${name} is not a plain hex: ${raw}`);
  const n = hex[1];
  return [
    Number.parseInt(n.slice(0, 2), 16),
    Number.parseInt(n.slice(2, 4), 16),
    Number.parseInt(n.slice(4, 6), 16),
  ];
}

/** sRGB channel -> linear (WCAG 2.x). */
function channel(c: number): number {
  const s = c / 255;
  return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

/** WCAG relative luminance of an [r,g,b]. */
function relLum([r, g, b]: Rgb): number {
  return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
}

/** WCAG contrast ratio between two colors. */
function contrast(a: Rgb, b: Rgb): number {
  const la = relLum(a);
  const lb = relLum(b);
  const hi = Math.max(la, lb);
  const lo = Math.min(la, lb);
  return (hi + 0.05) / (lo + 0.05);
}

const ELEVATION_PLANES = [
  '--surface-deep',
  '--surface-bg',
  '--surface-raised',
  '--surface-overlay',
] as const;

// The transient interaction tints a card swaps its background to while the user
// hovers/presses it. They sit LIGHTER than the rest planes, so quiet text on a
// card must still clear AA against them — otherwise a timecode/label goes
// sub-4.5:1 the instant the card is touched. (WU-2d.)
const INTERACTION_PLANES = ['--surface-hover', '--surface-active'] as const;

describe('dark-editorial surface ladder recalibration (WU-2a)', () => {
  it('lifts the base OFF pure near-black (canvas is a real, not-black surface)', () => {
    const tokens = readTokens();
    const bg = toRgb(tokens, '--surface-bg');
    const deep = toRgb(tokens, '--surface-deep');
    // The canvas sits clearly above the media-well floor AND above a flat
    // near-black threshold (the old #0e0f12 canvas was ~0.0046).
    expect(relLum(bg)).toBeGreaterThan(0.006);
    expect(relLum(bg)).toBeGreaterThan(relLum(deep) * 1.4);
  });

  it('keeps the whole ladder COOL blue-gray (locked mood — blue channel dominant)', () => {
    const tokens = readTokens();
    for (const name of [
      '--surface-bg',
      '--surface-raised',
      '--surface-overlay',
      '--surface-hover',
      '--surface-active',
    ]) {
      const [r, g, b] = toRgb(tokens, name);
      // Blue leads, green sits between, red trails — a deliberate cool cast with
      // real margin, never a neutral or warm grey.
      expect(b).toBeGreaterThan(g);
      expect(g).toBeGreaterThan(r);
      expect(b - r).toBeGreaterThanOrEqual(8);
    }
  });

  it('WIDENS the ladder into monotonic, visibly distinct planes', () => {
    const tokens = readTokens();
    const order = [
      '--surface-deep',
      '--surface-bg',
      '--surface-raised',
      '--surface-overlay',
      '--surface-hover',
      '--surface-active',
    ];
    const lums = order.map((n) => relLum(toRgb(tokens, n)));
    for (let i = 1; i < lums.length; i += 1) {
      expect(lums[i]).toBeGreaterThan(lums[i - 1]);
    }
    // The canvas->card and card->overlay rungs (the actual "flat plane" complaint)
    // each carry a perceptible contrast step, and the total spread is real.
    expect(
      contrast(toRgb(tokens, '--surface-bg'), toRgb(tokens, '--surface-raised')),
    ).toBeGreaterThanOrEqual(1.1);
    expect(
      contrast(toRgb(tokens, '--surface-raised'), toRgb(tokens, '--surface-overlay')),
    ).toBeGreaterThanOrEqual(1.1);
    expect(
      contrast(toRgb(tokens, '--surface-deep'), toRgb(tokens, '--surface-overlay')),
    ).toBeGreaterThanOrEqual(1.3);
  });

  it('holds --text-faint at AA (>=4.5:1) on every elevation plane', () => {
    const tokens = readTokens();
    const faint = toRgb(tokens, '--text-faint');
    for (const plane of ELEVATION_PLANES) {
      expect(contrast(faint, toRgb(tokens, plane))).toBeGreaterThanOrEqual(4.5);
    }
  });

  it('holds --text-faint at AA (>=4.5:1) on the hover + active interaction tints too', () => {
    // WU-2d: cards flip their bg to --surface-hover / --surface-active on
    // interaction, so faint (its quietest text) must still clear AA there — not
    // just on the seated elevation planes.
    const tokens = readTokens();
    const faint = toRgb(tokens, '--text-faint');
    for (const plane of INTERACTION_PLANES) {
      expect(contrast(faint, toRgb(tokens, plane))).toBeGreaterThanOrEqual(4.5);
    }
  });

  it('keeps a legible text hierarchy above the quiet steps', () => {
    const tokens = readTokens();
    const primary = relLum(toRgb(tokens, '--text-primary'));
    const secondary = relLum(toRgb(tokens, '--text-secondary'));
    const muted = relLum(toRgb(tokens, '--text-muted'));
    const faint = relLum(toRgb(tokens, '--text-faint'));
    // Primary reads loudest, secondary clearly above both quiet label steps.
    expect(primary).toBeGreaterThan(secondary);
    expect(secondary).toBeGreaterThan(muted);
    expect(secondary).toBeGreaterThan(faint);
    // WU-2d: muted is the LOUDER quiet step — it must sit lighter than faint
    // (fixes the WU-2a luminance inversion where muted was darker than faint).
    expect(muted).toBeGreaterThan(faint);
  });

  it('defines a layered elevation scale (e0 flush -> e3 lifted) for real depth', () => {
    const tokens = readTokens();
    expect(tokens.get('--elev-0')).toBe('none');
    // e1..e3 each pair an inset top-highlight with a drop shadow (layered depth),
    // and the ambient drop grows with height.
    for (const name of ['--elev-1', '--elev-2', '--elev-3']) {
      expect(tokens.get(name)).toContain('inset 0 1px 0');
    }
  });
});

// --- PR #290: red-text AA guard — error-alert text on the soft-error wash --------
//
// The error-alert TEXT (e.g. .director-view__error) sits on the translucent
// --status-error-soft wash. The saturated base --status-error (#e5484d),
// composited over that wash on the LIFTED elevation planes, drops to ~3.2-4.2:1 —
// a real WCAG 1.4.3 (AA) fail for body-size text. The fix is a dedicated red-TEXT
// token (--status-error-text, a lighter tint) mirroring the --status-abundance-text
// "lighter tint for AA on the wash" precedent. This guard re-derives the sRGB
// composite + WCAG contrast INDEPENDENTLY and pins that the red-text token clears
// 4.5:1 on EVERY elevation plane — and that it is genuinely lighter than (and the
// base red genuinely fails on) that wash — so alert text can never silently decay
// back to the sub-AA saturated red.

/** Parse an `rgba(r, g, b, a)` token into [r, g, b, a]. Throws if not an rgba(). */
function toRgba(
  tokens: Map<string, string>,
  name: string,
): readonly [number, number, number, number] {
  const raw = tokens.get(name);
  if (raw === undefined) throw new Error(`missing token ${name}`);
  const m = /^rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)$/.exec(raw);
  if (m === null) throw new Error(`token ${name} is not an rgba(): ${raw}`);
  return [Number(m[1]), Number(m[2]), Number(m[3]), Number.parseFloat(m[4])];
}

/** Alpha-composite a translucent wash over an opaque plane in sRGB 0-255 — how the
 * browser blends a background-color alpha over its backdrop (source-over). */
function over(wash: readonly [number, number, number, number], plane: Rgb): Rgb {
  const [wr, wg, wb, a] = wash;
  const [pr, pg, pb] = plane;
  return [a * wr + (1 - a) * pr, a * wg + (1 - a) * pg, a * wb + (1 - a) * pb];
}

describe('red-text token clears AA on the soft-error wash (PR #290)', () => {
  it('defines --status-error-text as a lighter tint than --status-error', () => {
    const tokens = readTokens();
    // toRgb throws unless the token is a plain #rrggbb; the text token is a
    // genuinely lighter red (the fix direction — it lifts the saturated base up to
    // an AA-legible tint on the wash), never a copy of the base value.
    expect(relLum(toRgb(tokens, '--status-error-text'))).toBeGreaterThan(
      relLum(toRgb(tokens, '--status-error')),
    );
  });

  it('holds --status-error-text at AA (>=4.5:1) on the wash over every elevation plane', () => {
    const tokens = readTokens();
    const text = toRgb(tokens, '--status-error-text');
    const wash = toRgba(tokens, '--status-error-soft');
    for (const plane of ELEVATION_PLANES) {
      expect(contrast(text, over(wash, toRgb(tokens, plane)))).toBeGreaterThanOrEqual(4.5);
    }
  });

  it('proves the base --status-error FAILS AA on that wash (why the token exists)', () => {
    // Documents the exact regression the token fixes: the base red on the wash
    // drops below AA on the lifted planes (here --surface-raised, ~3.75:1), so a
    // component MUST route alert text through --status-error-text, not --status-error.
    const tokens = readTokens();
    const base = toRgb(tokens, '--status-error');
    const wash = toRgba(tokens, '--status-error-soft');
    expect(contrast(base, over(wash, toRgb(tokens, '--surface-raised')))).toBeLessThan(4.5);
  });
});

// --- WU-D1: TYPE / WEIGHT / CONTROL token-scale completeness guard ---------------
//
// The design review found the type layer incomplete: NO font-weight tokens (raw
// 400/600/650/700/800 scattered through the component CSS) and a spray of orphan
// font-sizes outside the 4-rung scale (the 12px control size on every
// button/tab/toggle, plus 10/14/15/24px roles and a 17->30 subhead gap), and the
// control geometry (18px icon, 5/8px dots, the off-grid control paddings) sat as
// raw px. WU-D1 pulls all of it onto ONE token vocabulary. These tests are the
// REAL guard: they pin the ramp order + the exact role/control values AND assert
// the component sheets carry NO raw font-weight/font-size (so nobody can silently
// re-scatter raw values), and that every new token is actually CONSUMED — not just
// defined then abandoned.

/** A raw numeric font-weight (`font-weight: 600`), i.e. NOT `var(--weight-…)`. */
const RAW_FONT_WEIGHT = /font-weight:\s*\d/g;
/** A raw pixel font-size (`font-size: 12px`), i.e. NOT `var(--type-…)`. */
const RAW_FONT_SIZE = /font-size:\s*\d+px/g;

describe('type / weight / control token scale (WU-D1)', () => {
  it('defines an ordered font-weight ramp (regular -> heavy), monotonically increasing', () => {
    const tokens = readTokens();
    const ramp = [
      '--weight-regular',
      '--weight-medium',
      '--weight-semibold',
      '--weight-bold',
      '--weight-heavy',
    ] as const;
    const values = ramp.map((name) => {
      const raw = tokens.get(name);
      if (raw === undefined) throw new Error(`missing weight token ${name}`);
      return Number.parseInt(raw, 10);
    });
    // Exact numeric contract — the scattered raw weights the ramp replaces.
    expect(values).toEqual([400, 600, 650, 700, 800]);
    // Strictly increasing, so the ladder can never invert.
    for (let i = 1; i < values.length; i += 1) {
      expect(values[i]).toBeGreaterThan(values[i - 1]);
    }
    // The display composite sits inside the heavy tier: bold < display(750) < heavy.
    const display = Number.parseInt(tokens.get('--type-display-weight') ?? '', 10);
    expect(display).toBeGreaterThan(values[3]);
    expect(display).toBeLessThan(values[4]);
  });

  it('defines the role type-size tokens the design review pulled back onto the scale', () => {
    const tokens = readTokens();
    const sizes: Readonly<Record<string, string>> = {
      '--type-subhead-size': '22px',
      '--type-control-size': '12px',
      '--type-card-title-size': '14px',
      '--type-hook-size': '15px',
      '--type-rank-size': '24px',
      '--type-chip-size': '10px',
    };
    for (const [name, px] of Object.entries(sizes)) {
      expect(tokens.get(name)).toBe(px);
    }
    // The subhead rung genuinely fills the title(17) -> display(30) gap.
    const px = (name: string): number => Number.parseInt(tokens.get(name) ?? '', 10);
    expect(px('--type-subhead-size')).toBeGreaterThan(px('--type-title-size'));
    expect(px('--type-subhead-size')).toBeLessThan(px('--type-display-size'));
  });

  it('defines the control-sizing tokens (icon + glyph + dots + control padding)', () => {
    const tokens = readTokens();
    expect(tokens.get('--size-icon')).toBe('18px');
    expect(tokens.get('--size-glyph')).toBe('20px');
    expect(tokens.get('--size-glyph-lg')).toBe('26px');
    expect(tokens.get('--size-dot')).toBe('8px');
    expect(tokens.get('--size-dot-sm')).toBe('5px');
    // A dot is smaller than a control icon (geometry sanity, not just presence).
    expect(Number.parseInt(tokens.get('--size-dot') ?? '', 10)).toBeLessThan(
      Number.parseInt(tokens.get('--size-icon') ?? '', 10),
    );
    // Control paddings are `<y>px <x>px` shorthands (value preserved, no restyle).
    for (const name of [
      '--control-pad-toggle',
      '--control-pad-btn',
      '--control-pad-input',
      '--control-pad-toptab',
      '--control-pad-tab',
      '--control-pad-mini',
    ]) {
      expect(tokens.get(name)).toMatch(/^\d+px \d+px$/);
    }
  });

  it('routes the component sheets through the tokens — NO raw font-weight/size survives', () => {
    for (const path of [SHELL_CSS, TOPTAB_CSS, LIB_CARDS_CSS]) {
      const css = stripComments(readFileSync(path, 'utf8'));
      expect(css.match(RAW_FONT_WEIGHT) ?? []).toEqual([]);
      expect(css.match(RAW_FONT_SIZE) ?? []).toEqual([]);
    }
  });

  it('proves the ramp + role + control tokens are actually CONSUMED (a real guard)', () => {
    const shell = stripComments(readFileSync(SHELL_CSS, 'utf8'));
    const toptab = stripComments(readFileSync(TOPTAB_CSS, 'utf8'));
    const cards = stripComments(readFileSync(LIB_CARDS_CSS, 'utf8'));
    // Weight ramp: the regular rung is consumed by the body-weight token itself
    // (--type-body-weight routes through var(--weight-regular), so the ramp is DRY
    // and no rung is a defined-then-abandoned orphan); the rest are consumed
    // explicitly in the shell.
    expect(readTokens().get('--type-body-weight')).toBe('var(--weight-regular)');
    for (const name of [
      '--weight-medium',
      '--weight-semibold',
      '--weight-bold',
      '--weight-heavy',
    ]) {
      expect(shell).toContain(`var(${name})`);
    }
    // Type role sizes.
    for (const name of [
      '--type-control-size',
      '--type-card-title-size',
      '--type-hook-size',
      '--type-rank-size',
      '--type-chip-size',
      '--type-subhead-size',
    ]) {
      expect(shell).toContain(`var(${name})`);
    }
    // Control sizing: dots + glyphs in the shell/cards, the icon slot in the top tabs.
    expect(shell).toContain('var(--size-dot)');
    expect(shell).toContain('var(--size-dot-sm)');
    expect(shell).toContain('var(--size-glyph)');
    expect(cards).toContain('var(--size-glyph-lg)');
    expect(toptab).toContain('var(--size-icon)');
    // Control padding role tokens.
    for (const name of [
      '--control-pad-toggle',
      '--control-pad-btn',
      '--control-pad-input',
      '--control-pad-tab',
      '--control-pad-mini',
    ]) {
      expect(shell).toContain(`var(${name})`);
    }
    expect(toptab).toContain('var(--control-pad-toptab)');
  });
});

// --- WU-D7: no undefined custom-property references anywhere in renderer CSS -----
//
// The design review found REPO-WIDE token sprawl: ~17 renderer sheets referenced
// custom properties that tokens.css never defines (e.g. --surface-1/2,
// --border-subtle, --type-small-size, --surface-edge, --status-danger,
// --status-warning, --muted, --text, --surface, --color-*). Several had NO
// fallback, so the whole declaration was INVALID and silently dropped — broken /
// off-theme styling that no test caught. WU-D7 remaps every one onto a REAL token
// (surface ladder / text ladder / --edge / --status-* / --type-* / --weight-* /
// --space-* / --radius-*).
//
// This is the REAL guard so it can never regress: it walks EVERY renderer *.css,
// collects the union of all DEFINED custom properties (tokens.css plus the handful
// of locally-scoped ones like --timeline-wave), then asserts that EVERY var(--x)
// reference — including tokens nested inside fallbacks — resolves to a defined
// property. A single stray var(--not-a-token) fails the suite with the offending
// token + file, so the sprawl cannot silently creep back.

const RENDERER_SRC = resolve(HERE, '..');

/** Recursively collect every `*.css` file path under a directory. */
function collectCssFiles(dir: string): readonly string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      out.push(...collectCssFiles(full));
    } else if (entry.isFile() && entry.name.endsWith('.css')) {
      out.push(full);
    }
  }
  return out;
}

/** All custom-property NAMES defined (`--name: value;`) in a stylesheet body. */
function definedProps(css: string): readonly string[] {
  const decl = /(--[\w-]+)\s*:/g;
  const names: string[] = [];
  for (let m = decl.exec(css); m !== null; m = decl.exec(css)) {
    names.push(m[1]);
  }
  return names;
}

describe('no undefined custom-property references in renderer CSS (WU-D7)', () => {
  const cssFiles = collectCssFiles(RENDERER_SRC);

  it('finds the renderer stylesheets (guard is actually scanning something)', () => {
    // A dead scan that matches zero files would vacuously "pass" — pin a floor so
    // the guard proves it is exercising the real sheet set (there are dozens).
    expect(cssFiles.length).toBeGreaterThan(20);
    expect(cssFiles.some((f) => f.endsWith('tokens.css'))).toBe(true);
  });

  it('resolves EVERY var(--x) to a token defined somewhere in the renderer CSS', () => {
    // Union of every defined custom property: the tokens.css design system plus any
    // locally-scoped props a sheet declares for its own use (e.g. --timeline-wave).
    const defined = new Set<string>();
    for (const file of cssFiles) {
      for (const name of definedProps(stripComments(readFileSync(file, 'utf8')))) {
        defined.add(name);
      }
    }

    // Collect every reference that does NOT resolve, tagged with its file so a
    // failure names exactly what to fix.
    const offenders: string[] = [];
    for (const file of cssFiles) {
      const css = stripComments(readFileSync(file, 'utf8'));
      const ref = /var\(\s*(--[\w-]+)/g;
      for (let m = ref.exec(css); m !== null; m = ref.exec(css)) {
        if (!defined.has(m[1])) {
          offenders.push(`${relative(RENDERER_SRC, file).replace(/\\/g, '/')}: var(${m[1]})`);
        }
      }
    }

    // Empty is the only acceptable state — every consumed token must be real.
    expect(offenders).toEqual([]);
  });
});

// --- v1.5 pro-shell token evolution (Wave-2) -------------------------------------
//
// The v1.5 redesign consumes the SHIPPED tokens (never the prototype's literal
// hex — §5.A) and evolves the layer DELIBERATELY (§5.B): real bundled type faces
// leading the UI / editorial / mono families, and a glass / floating-surface
// layer for the produced-shorts modal (and the Cmd-K palette when it ships,
// §7.5). These are the LOCK on that evolution — additive to the guards above,
// never a weakening of them. A font family that decays back to a bare generic
// (`system-ui` / `Georgia` / `ui-monospace` leading), or a glass layer that
// loses its translucency / blur, fails here.

/** The FIRST family in a `font-family` list (before the first comma), trimmed. */
function leadFamily(value: string): string {
  return (value.split(',')[0] ?? '').trim().replace(/^["']|["']$/g, '');
}

/** The alpha channel of an `rgba(r,g,b,a)` value, or NaN when not an rgba(). */
function rgbaAlpha(value: string): number {
  const m = /rgba\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+\s*,\s*([\d.]+)\s*\)/.exec(value);
  return m ? Number.parseFloat(m[1]) : Number.NaN;
}

describe('v1.5 shell token evolution — type faces (WU-1.5)', () => {
  it('leads --font-ui with a bundled non-generic face (Inter / Geist), keeping a system fallback', () => {
    const value = readTokens().get('--font-ui') ?? '';
    // The lead is a real bundled UI face, NOT the generic system-ui the prototype
    // superseded (§5.B). A system fallback stays LAST so it renders before the
    // @font-face binaries are bundled (documented follow-up).
    expect(['Inter', 'Geist']).toContain(leadFamily(value));
    expect(value).toContain('system-ui');
    expect(value.trimEnd()).toMatch(/sans-serif;?$/);
  });

  it('sets --font-editorial to Newsreader with a serif fallback (the pull-quote voice)', () => {
    const value = readTokens().get('--font-editorial') ?? '';
    // Newsreader supersedes the stale Georgia lead; a generic serif stays as the
    // fallback so the editorial voice never collapses to sans.
    expect(leadFamily(value)).toBe('Newsreader');
    expect(value.trimEnd()).toMatch(/serif;?$/);
  });

  it('leads --font-mono with a bundled mono face, keeping a monospace fallback (timecode voice)', () => {
    const value = readTokens().get('--font-mono') ?? '';
    expect(leadFamily(value)).toBe('IBM Plex Mono');
    expect(value.trimEnd()).toMatch(/monospace;?$/);
  });
});

describe('v1.5 shell token evolution — glass / floating-surface layer (WU-1.5)', () => {
  it('defines a translucent glass surface + a real backdrop-blur radius', () => {
    const tokens = readTokens();
    // The glass surface is the raised plane at REDUCED opacity so a backdrop-blur
    // reads through it — a solid fill would defeat the layer.
    const glass = tokens.get('--surface-glass') ?? '';
    const alpha = rgbaAlpha(glass);
    expect(alpha).toBeGreaterThan(0);
    expect(alpha).toBeLessThan(1);
    // A non-zero px blur radius (the layer is meaningless at 0).
    const blur = tokens.get('--glass-blur') ?? '';
    expect(blur).toMatch(/^\d+px$/);
    expect(Number.parseInt(blur, 10)).toBeGreaterThan(0);
  });

  it('defines the centered-surface scrim + measure (modal now, Cmd-K palette later)', () => {
    const tokens = readTokens();
    // The scrim that dims the canvas behind a centered floating surface: a
    // translucent dark wash (alpha < 1 so the app stays faintly visible behind).
    const scrim = tokens.get('--overlay-scrim') ?? '';
    const alpha = rgbaAlpha(scrim);
    expect(alpha).toBeGreaterThan(0);
    expect(alpha).toBeLessThan(1);
    // A pixel max-measure so the floating surface never spans an ultrawide window.
    expect(tokens.get('--overlay-width') ?? '').toMatch(/^\d+px$/);
  });
});

describe('v1.5 shell token evolution — locks the reconciled §5.A guardrails (WU-1.5)', () => {
  it('pins the ink-on-accent value the redesign must bind (never the prototype #1a1205)', () => {
    expect(readTokens().get('--accent-ink')).toBe('#211404');
  });

  it('keeps --text-faint OFF the rejected sub-AA #50555F (the WCAG 1.4.3 regression)', () => {
    // The prototype re-introduced #50555F (~2.4:1) on quiet text; the shipped faint
    // step is a real AA tone. Guard the exact rejected value can never creep back.
    const faint = (readTokens().get('--text-faint') ?? '').toLowerCase();
    expect(faint).not.toBe('#50555f');
  });

  it('pins the motion ladder (fast < base < slow) + a real easing curve', () => {
    const tokens = readTokens();
    const ms = (name: string): number => Number.parseInt(tokens.get(name) ?? '', 10);
    const fast = ms('--dur-fast');
    const base = ms('--dur-base');
    const slow = ms('--dur-slow');
    expect(fast).toBe(120);
    expect(base).toBe(180);
    expect(slow).toBe(260);
    expect(fast).toBeLessThan(base);
    expect(base).toBeLessThan(slow);
    expect(tokens.get('--ease-out') ?? '').toContain('cubic-bezier(');
  });
});

// --- v1.5 shell-polish: red status TEXT must clear AA (the DoD contrast floor) ---
//
// The visual audit found #e5484d (--status-error, the SOLID signal red) used as
// TEXT — the FAILED chip, "Missing", "Unavailable" — sitting at ~4.1:1 on
// --surface-raised, UNDER the 4.5:1 AA floor the DoD pins (green ~7.3:1 / amber
// ~9.3:1 already clear it). The fix SPLITS the token: --status-error stays the
// solid FILL/BORDER red (unchanged — zero fill regression), and a NEW
// --status-error-text carries a lighter, AA-safe red for every red STRING. These
// tests PIN that invariant (never weaken it): the text red clears AA on every
// elevation plane, sits LIGHTER than the fill red, and the Library sheets route
// their red text through the AA-safe token (no bare `color: var(--status-error)`).

/** A bare `color: var(--status-error)` text leak — NOT border-color, NOT -soft/-text. */
const RED_TEXT_LEAK = /[^-]color:\s*var\(--status-error\)/g;

/** The Library sheets whose red TEXT was migrated to the AA-safe token. */
const LIBRARY_RED_TEXT_SHEETS = [
  resolve(HERE, '..', 'components', 'library-cards.css'),
  resolve(HERE, '..', 'components', 'library-shell.css'),
  resolve(HERE, '..', 'components', 'readinessBadge.css'),
  resolve(HERE, '..', 'features', 'library-provenance.css'),
  resolve(HERE, '..', 'features', 'keep-copy-control.css'),
] as const;

describe('red status text clears AA — the DoD contrast floor (v1.5 shell-polish)', () => {
  it('defines an AA-safe red TEXT token, lighter than the unchanged solid fill red', () => {
    const tokens = readTokens();
    // The fill red is untouched (no regression to the FAILED-dot / progress fills);
    // the text red is a distinct, lighter tone.
    expect(tokens.get('--status-error')).toBe('#e5484d');
    const fill = toRgb(tokens, '--status-error');
    const text = toRgb(tokens, '--status-error-text');
    expect(relLum(text)).toBeGreaterThan(relLum(fill));
  });

  it('holds red TEXT at AA (>=4.5:1) on every elevation plane', () => {
    const tokens = readTokens();
    const text = toRgb(tokens, '--status-error-text');
    for (const plane of ELEVATION_PLANES) {
      expect(contrast(text, toRgb(tokens, plane))).toBeGreaterThanOrEqual(4.5);
    }
  });

  it('holds the green + amber status TEXT at AA on raised (the whole ladder passes)', () => {
    const tokens = readTokens();
    const raised = toRgb(tokens, '--surface-raised');
    // Green (success) + amber (warn) are light enough to double as text already;
    // pin them so the status-text ladder cannot silently drop below AA either.
    expect(contrast(toRgb(tokens, '--status-success'), raised)).toBeGreaterThanOrEqual(4.5);
    expect(contrast(toRgb(tokens, '--status-warn'), raised)).toBeGreaterThanOrEqual(4.5);
  });

  it('routes Library red TEXT through the AA-safe token (no bare status-error text)', () => {
    for (const path of LIBRARY_RED_TEXT_SHEETS) {
      const css = stripComments(readFileSync(path, 'utf8'));
      expect(css.match(RED_TEXT_LEAK) ?? []).toEqual([]);
    }
    // …and the AA-safe token is actually consumed as text in the Library sheets.
    const consumed = LIBRARY_RED_TEXT_SHEETS.some((p) =>
      stripComments(readFileSync(p, 'utf8')).includes('var(--status-error-text)'),
    );
    expect(consumed).toBe(true);
  });
});

// --- H7: the editorial serif is CAPPED to an enumerated allowlist -----------------
//
// docs/plans/v1.5/uiux-qol-audit-2026-08.md sec.3.1 measured `--font-editorial`
// in 15 places against a documented limit of ONE, and named the real defect in
// the same breath: "undetected by the conformance suite that already guards the
// accent". The accent had a whole-tree guard; the second scarce typographic
// channel had none, so it spread one reasonable-looking commit at a time.
//
// This is that guard. It is an ALLOWLIST, not a count: a 15th site fails until
// someone adds the selector here, which turns silent drift into a reviewed
// decision. A count alone would let a swap slip through unnoticed.
//
// The list is NOT a rubber-stamp of whatever was there. Every entry is a hook
// pull-quote, an empty-state title, or a panel/modal display title — the
// editorial voice. `.director-view__title` was REMOVED rather than admitted: it
// was the only one of four `*-view__title` rules to take the serif, and the only
// one at display size instead of title size (caption.css:39, deliver.css:39 and
// export.css:39 are the three that agree). View chrome is the one place this
// voice does not belong.
//
// Body text, labels, controls, data and timecode are never eligible.

/** Every selector permitted to set `font-family: var(--font-editorial)`. */
const EDITORIAL_SERIF_ALLOWLIST: readonly string[] = [
  // hook pull-quotes — the original documented home
  '.sm-hook',
  '.shorts__hook',
  '.caption-stage__hint',
  // empty-state titles
  '.caption-inspector__empty-title',
  '.caption-view__empty-title',
  '.export-view__empty-title',
  // panel / modal / result display titles
  '.shorts-modal__title',
  '.director-handoff__title',
  '.lineage-panel__title',
  '.export-inspector__confirm-title',
  // W04 — REVIEWED ALLOWLIST ADDITION. `.confirm-dialog-title` is the SAME node as
  // `.export-inspector__confirm-title` above: both are rendered by the one shared
  // <ConfirmDialog/> (components/ConfirmDialog.tsx), only under a different BEM
  // block. It is a modal display title — the third category this list already
  // admits — and refusing it here would make the six former native-`confirm()`
  // gates read typographically differently from the export gate they were lifted
  // from. This adds no NEW site: it is the existing site under its second skin.
  '.confirm-dialog-title',
  '.export-result__title',
  // identity / display moments
  '.first-run-setup__brand',
  '.profile-picker__legend',
  '.caption-gallery__current',
];

/**
 * Selectors that set `font-family: var(--font-editorial)` in one stylesheet.
 *
 * Reads the selector list immediately preceding each declaration's `{`. Comments
 * are stripped FIRST so a selector quoted inside a comment cannot register as a
 * real use (the use-vs-mention trap).
 */
function editorialSerifSelectors(css: string): readonly string[] {
  const body = stripComments(css);
  const out: string[] = [];
  const rule = /([^{}]+)\{([^{}]*)\}/g;
  for (let m = rule.exec(body); m !== null; m = rule.exec(body)) {
    if (!/font-family\s*:\s*var\(--font-editorial\)/.test(m[2])) continue;
    for (const sel of m[1].split(',')) {
      const trimmed = sel.trim().replace(/\s+/g, ' ');
      if (trimmed) out.push(trimmed);
    }
  }
  return out;
}

describe('editorial serif stays inside its allowlist (H7)', () => {
  const cssFiles = collectCssFiles(RENDERER_SRC);

  it('finds the renderer stylesheets (guard is actually scanning something)', () => {
    // A dead scan matching zero files would vacuously pass. Pin a floor, and pin
    // that the detector CAN see a known-present use, before trusting its silence.
    expect(cssFiles.length).toBeGreaterThan(20);
    const anyUse = cssFiles.flatMap((f) => editorialSerifSelectors(readFileSync(f, 'utf8')));
    expect(anyUse.length).toBeGreaterThan(0);
  });

  it('every --font-editorial site is on the allowlist', () => {
    const offenders: string[] = [];
    for (const file of cssFiles) {
      for (const sel of editorialSerifSelectors(readFileSync(file, 'utf8'))) {
        if (!EDITORIAL_SERIF_ALLOWLIST.includes(sel)) {
          offenders.push(`${sel}  (${file.replace(RENDERER_SRC, '')})`);
        }
      }
    }
    // The message names the offender AND what to do, so the failure is actionable
    // without opening this file.
    expect(
      offenders,
      'New --font-editorial site(s). The editorial serif is a SCARCE channel ' +
        '(docs/design-system.md): hook pull-quotes, empty-state titles and panel ' +
        'display titles only — never body text, labels, controls or data. If this ' +
        'use really is one of those, add the selector to EDITORIAL_SERIF_ALLOWLIST.',
    ).toEqual([]);
  });

  it('the allowlist has no dead entries (it tracks the tree, not history)', () => {
    // The other direction: an allowlisted selector that no longer sets the serif
    // is stale permission, and stale permission is how an allowlist rots into a
    // rubber stamp.
    const live = new Set(cssFiles.flatMap((f) => editorialSerifSelectors(readFileSync(f, 'utf8'))));
    expect(EDITORIAL_SERIF_ALLOWLIST.filter((s) => !live.has(s))).toEqual([]);
  });

  it('no VIEW header uses the serif — the four view titles agree', () => {
    // The specific regression H7 named. Pinned separately from the allowlist so
    // re-adding `.director-view__title` to the list cannot quietly re-open it.
    const viewTitles = cssFiles.flatMap((f) =>
      editorialSerifSelectors(readFileSync(f, 'utf8')).filter((s) => /view__title$/.test(s)),
    );
    expect(viewTitles).toEqual([]);
  });
});

// --- H5: the global form-control floor actually exists and is wired ---------------
//
// sec.3.4 / H5: "Deliver leaks unstyled native HTML — a raw <fieldset> and a
// 23x20 px Template select. Add a global `select` rule to the token layer".
//
// Measured before the fix: NO element-level rule for select / fieldset / legend
// existed anywhere in the renderer, so ~50 selects and 7 fieldsets rendered as
// raw platform chrome. The tell that this was an oversight and not a decision:
// tokens.css already defined `--control-pad-input` and documented it as "text
// inputs / selects" — authored for a rule that was never written.
//
// These pin the floor so it cannot silently disappear again. A stylesheet that
// exists but is never IMPORTED styles nothing, so the import is pinned too — that
// is the failure mode a file-existence check alone would miss.

const CONTROLS_CSS = resolve(HERE, 'controls.css');
const APP_TSX = resolve(HERE, '..', 'App.tsx');

describe('global form-control floor (H5)', () => {
  it('defines element-level select, fieldset and legend rules', () => {
    const css = stripComments(readFileSync(CONTROLS_CSS, 'utf8'));
    // Element selectors at the start of a rule — NOT `.some-class select`, which
    // would be a component override rather than the global floor.
    for (const el of ['select', 'fieldset', 'legend']) {
      expect(new RegExp(`(^|\\})\\s*${el}\\s*\\{`).test(css), `${el} floor rule`).toBe(true);
    }
  });

  it('is imported by App.tsx AFTER tokens.css (so the properties resolve)', () => {
    const app = readFileSync(APP_TSX, 'utf8');
    const tokensAt = app.indexOf('styles/tokens.css');
    const controlsAt = app.indexOf('styles/controls.css');
    expect(controlsAt, 'controls.css is imported').toBeGreaterThan(-1);
    expect(tokensAt, 'tokens.css is imported').toBeGreaterThan(-1);
    // A sheet that loads before its custom properties resolves them to nothing.
    expect(controlsAt).toBeGreaterThan(tokensAt);
  });

  it('consumes the select padding token the design system already declared', () => {
    // The specific dangling token H5 exposed. If a future edit hardcodes padding
    // here, the token goes orphaned again and the audit finding silently returns.
    const css = stripComments(readFileSync(CONTROLS_CSS, 'utf8'));
    expect(css).toContain('var(--control-pad-input)');
  });

  it('uses NO raw colour literals — every value routes through a token', () => {
    // Same discipline the one-accent guard applies to usageBar.css. A hex or
    // rgb() here would be a colour off the ladder, in a sheet that touches every
    // control in the app.
    const css = stripComments(readFileSync(CONTROLS_CSS, 'utf8'));
    expect(css.match(/#[0-9a-fA-F]{3,8}\b/g) ?? []).toEqual([]);
    expect(css.match(/\b(?:rgba?|hsla?)\(/g) ?? []).toEqual([]);
  });

  it('gives the select a real hit target (the 23x20 px control H5 measured)', () => {
    const css = stripComments(readFileSync(CONTROLS_CSS, 'utf8'));
    const m = /min-height:\s*(\d+)px/.exec(css);
    expect(m, 'select min-height floor').not.toBeNull();
    expect(Number(m?.[1])).toBeGreaterThanOrEqual(28);
  });
});

// --- W15: the red-TEXT AA floor is enforced TREE-WIDE, not on five sheets ----------
//
// The `routes Library red TEXT through the AA-safe token` guard at :688 is allowlisted
// to exactly FIVE sheets, so it stayed permanently green while the very defect its
// comment describes shipped everywhere else. Measured at origin/main 775a97ea over the
// 65 renderer stylesheets:
//   * 26 sheets reference `color: var(--status-error)` in some form;
//   * 6 of those are background-color / border-color ONLY — the CORRECT use of the
//     solid fill red, and deliberately untouched here;
//   * the remaining 20 sheets / 34 rules used the FILL red as a red STRING, unchecked.
//
// Re-derived below with this file's own contrast() helper, the fill red #e5484d AS TEXT:
//   --surface-deep 4.97 | --surface-bg 4.62 | --surface-raised 4.12 |
//   --surface-overlay 3.53 | --surface-hover 3.17 | --surface-active 2.69
// and composited over the --status-error-soft wash that 21 of those 34 rules set on
// THEMSELVES (so that verdict needs no DOM at all):
//   deep 4.59 | bg 4.23 | raised 3.75 | overlay 3.24        — the AA floor is 4.50.
//
// So 31 of the 34 rules are measured sub-AA on the plane their own sheet puts them on:
// .jobqueue__status--error inherits .jobqueue__item = --surface-hover (3.17),
// .managed-meter__btn--danger inherits .managed-meter__btn = --surface-raised (4.12),
// .caption-prefs__error inherits .caption-prefs__frame whose gradient light end
// #2a2a38 gives 3.61.
//
// The other 3 — `.director-panel .director-op__reason`,
// `.consent-toggle__disclosure[data-trains="true"]` and
// `.picker-option__privacy[data-privacy="AVOID"]` — sit on --surface-bg and DO clear
// AA, at 4.62:1. They were routed to --status-error-text rather than allowlisted, and
// that is a judgement call worth stating: the margin is 0.12, one plane-lift to
// --surface-raised turns it into 4.12 FAIL, the WU-2a recalibration already moved
// these planes once, and the design-system rule is SEMANTIC — --status-error is the
// fill/border red and --status-error-text carries every red string (:641-646). Their
// own siblings already agree: .health-verdict.ok takes --status-success and
// .spend-cap__status[data-zone="near"] takes --status-warn, both pinned at AA at :679.
// Hence the allowlist below ships EMPTY *by measurement*, not by omission.
//
// SCOPE — read this before citing the guard. It pins WHICH TOKEN carries red text; it is
// NOT an AA floor, and it does NOT leave every migrated site at AA. Two sentences that
// shipped in the first pass of this block were REFUTED as overclaims and are corrected
// here rather than deleted:
//
//   REFUTED #1 — "a red string inside a hovered/pressed row improves (3.17 -> 4.47) but
//   stays ~0.03 under the floor", with 3.79 named as the worst case. Wrong state AND an
//   incomplete set. (a) --surface-hover is the RESTING background of `.jobqueue__item`
//   (components/jobqueue.css:177; :182 swaps to --surface-active on hover), so the failed-
//   job status string is 4.47:1 with NO interaction at all — not a state a user has to
//   provoke. (b) It omitted the COMPOSITE case: --status-error-text over its own
//   --status-error-soft 10%-alpha wash measures 4.12:1 on --surface-hover and **3.55:1** on
//   --surface-active. 3.55 — not 3.79 — is the worst post-fix value in this tree, and it is
//   reached by a rule W15 itself migrated: `.library__remove-btn:hover` /
//   `.sm-row-decide button[aria-label="Discard"]:hover` (components/shell.css:501-504) sets
//   the wash on ITSELF while its host card lifts to --surface-hover / --surface-active on
//   the SAME pointer event (components/library-cards.css:55-56, :69-72).
//   (c) The repo's own audit ledger had already computed and warned about that exact site:
//   docs/validation/v15-audit-ledger.md:477 — "Fixing the one-token color at shell.css:446
//   lifts hover to 4.13:1 (still under AA because the card tint compounds), so a complete
//   fix also needs the card-level tint suppressed". The first pass did not cite it.
//
// CORRECTLY SCOPED: every one of the 34 migrated sites IMPROVES, and AT LEAST TWO remain
// sub-AA after the migration — 4.47:1 (`.jobqueue__status--error`, at rest) and 3.55:1
// (the Remove/Discard label at press) — because --status-error-text (#ff6b6b) is itself
// under AA on the two interaction tints: 4.47 on --surface-hover, 3.79 on --surface-active
// (independently re-derived from raw hex, not via this file's helpers).
//
// "AT LEAST two" is a measured FLOOR, not a total. UNVERIFIED — how many of the 34 land on
// an interaction tint: 17 of the 20 migrated sheets set --surface-hover or --surface-active
// as a background somewhere, so more sites may resolve onto one. Settling experiment:
// getComputedStyle backgroundColor on every migrated node in the running app, in the resting
// AND hovered AND pressed state (the same probe the plane-resolution caveat below needs).
//
// Closing the two known ones needs a TOKEN-VALUE change plus tint suppression under the
// Library meta lane — both outside a routing guard — so the AA assertions here stay on
// ELEVATION_PLANES exactly as :671 does. Settling experiment: lift --status-error-text until
// contrast() clears 4.5 on --surface-active AND give the hovered Remove button an opaque own
// background, then re-run this file plus the five Library sheets.
//
// SIBLING GAP — DISCLOSED, deliberately NOT fixed here (out of W15's declared scope). This
// block's whole thesis is "a subset-scoped guard hides the defect everywhere else", and a
// structurally identical one is still live in this same file: :3-4 quotes tokens.css's rule
// of use as GLOBAL — "Consume tokens only — no one-off hex values in component CSS" — but the
// test that enforces it (`usageBar.css uses NO raw color literals`, :41, via USAGE_BAR_CSS
// at :26) is scoped to exactly ONE sheet. Measured with RAW_COLOR (:33) over all 65 sheets,
// comments stripped: 9 component sheets besides tokens.css carry raw literals —
// captionCustomizer (10), captionDesigner (10), captionStylePicker (8), captionBox (6),
// reframeOverridePanel (4), captionPreferences (3), captionOverlay (1), directorPanel (1),
// modelsSystem (1). W15 touched three of those (captionPreferences, directorPanel,
// modelsSystem) for the red-text migration without noting it. UNVERIFIED: whether each hit
// is a genuine violation — several are plausibly legitimate non-palette values (e.g.
// captionPreferences.css:71 `linear-gradient(160deg, #2a2a38, #0d0d12)` is the caption-
// preview surface; :78 `rgba(0, 0, 0, 0.9)` is a text-shadow alpha). Settling experiment: point
// RAW_COLOR at all 65 sheets and triage per-site, exactly as this block did for red text.

/**
 * A `color` declaration carrying the solid FILL red — the red used as a STRING.
 *
 * The lookbehind rejects `background-color` / `border-color` / `outline-color` by their
 * `-`; the trailing `[,)]` rejects the `-soft` / `-text` siblings (their next character is
 * `-`) while accepting the var() FALLBACK form `var(--status-error, #e5484d)`. `--danger`
 * is in the alternation because tokens.css:284 aliases it to the same fill red under a
 * "keep consumers working" comment, so `color: var(--danger)` is the same defect by another
 * spelling. Both extra forms have ZERO consumers today (measured over all 65 sheets, with
 * the probe controlled against a known-present `color: var(--danger)` string) — they are
 * closed here so a future lane cannot reach for either without tripping the guard.
 *
 * REFUTED, and corrected: the first pass claimed this pattern "catches a declaration that
 * starts a rule body with no preceding character" which the narrower RED_TEXT_LEAK at :649
 * (`[^-]color:`) "cannot match". False for the string the control cites — `{` satisfies
 * `[^-]`, so `.a{color:var(--status-error)}` matches BOTH (measured: OLD=HIT NEW=HIT). The
 * only body-start form :649 misses is a declaration at string index 0. The real, measured
 * widenings are whitespace tolerance: `color : var(...)` and `var( --status-error )` are
 * OLD=miss / NEW=HIT. Both patterns still agree exactly on this tree — re-measured against
 * the origin/main CSS blobs with a standalone probe (not this file): 20 sheets each, and 0
 * each at HEAD. So the widening changes which FUTURE spellings are caught, and changes
 * nothing about the migration set it was used to derive.
 *
 * Scoped to the `color` property on purpose: the tree contains zero references to
 * --status-error from `-webkit-text-fill-color` or `caret-color` (measured), so widening
 * further would add a branch no fixture exercises.
 */
const RED_TEXT_USE = /(?<![-\w])color\s*:\s*var\(\s*--(?:status-error|danger)\s*[,)]/;

/** A sheet that still consumes --status-error as a FILL (background / border / outline).
 *
 * `[^;{}]*` and not `[^;]*`: the loose form crosses a `}`, so a sheet whose background
 * and red text live in two SEPARATE rules would falsely count as a fill consumer. That
 * matters because the assertion below sits exactly at its floor (19 sheets, `>= 19`), so
 * one cross-block false positive would silently restore slack in the only test protecting
 * the fills from a bulk find-and-replace. Pinned by a control at :1088. */
const FILL_USE = /(?:background|border|outline)(?:-[\w-]+)?\s*:[^;{}]*var\(--status-error\)/;

/** Selectors that set the FILL red as text in ONE stylesheet — i.e. any spelling
 * RED_TEXT_USE matches, which since the refuter pass is `color: var(--status-error)`, its
 * var() fallback form, and the `--danger` alias.
 *
 * Comments are stripped FIRST so a declaration quoted inside a comment cannot register
 * as a real use (the use-vs-mention trap). */
function redTextSelectors(css: string): readonly string[] {
  const body = stripComments(css);
  const out: string[] = [];
  const rule = /([^{}]+)\{([^{}]*)\}/g;
  for (let m = rule.exec(body); m !== null; m = rule.exec(body)) {
    if (!RED_TEXT_USE.test(m[2])) continue;
    for (const sel of m[1].split(',')) {
      const trimmed = sel.trim().replace(/\s+/g, ' ');
      if (trimmed) out.push(trimmed);
    }
  }
  return out;
}

/** Allowlist entries matching no live site — stale permission, not a guard. */
function deadRedTextEntries(
  allowlist: readonly string[],
  live: readonly string[],
): readonly string[] {
  const seen = new Set(live);
  return allowlist.filter((sel) => !seen.has(sel));
}

/** Every selector permitted to carry the FILL red as text (any RED_TEXT_USE spelling). */
const RED_TEXT_ALLOWLIST: readonly string[] = [
  // EMPTY BY MEASUREMENT — see the block comment above. Every one of the 34 sites that
  // existed at 775a97ea was routed to --status-error-text. To add an entry here you owe
  // the next reader the measured ratio AND the background you measured it against.
];

describe('red status TEXT stays inside its allowlist, tree-wide (W15)', () => {
  const cssFiles = collectCssFiles(RENDERER_SRC);

  it('the red-text scanner CAN see a leak — a zero means zero for un-nested rules', () => {
    // Detector control in BOTH directions. The tree-wide assertion below returns an
    // empty offender list, which is only meaningful once this scanner is shown to fire
    // on a known-present leak and stay silent on the correct uses. The title is scoped to
    // un-nested rules on purpose — the nesting blind spot is pinned in the next test.
    expect(redTextSelectors('.a { color: var(--status-error); }')).toEqual(['.a']);
    expect(redTextSelectors('.a,\n.b { color: var(--status-error); }')).toEqual(['.a', '.b']);
    // Minified form. NOT a case :649 misses — `{` satisfies its `[^-]` (see the docstring's
    // REFUTED note). Kept because minified input must still tokenize.
    expect(redTextSelectors('.a{color:var(--status-error)}')).toEqual(['.a']);
    // The genuine widenings over :649, both measured OLD=miss / NEW=HIT:
    expect(redTextSelectors('.a { color : var(--status-error); }')).toEqual(['.a']);
    expect(redTextSelectors('.a { color: var( --status-error ); }')).toEqual(['.a']);
    // The FILL uses must NEVER be flagged: this guard may not force a fill to migrate.
    expect(redTextSelectors('.a { background-color: var(--status-error); }')).toEqual([]);
    expect(redTextSelectors('.a { border-color: var(--status-error); }')).toEqual([]);
    expect(redTextSelectors('.a { background: var(--status-error); }')).toEqual([]);
    expect(redTextSelectors('.a { border: 1px solid var(--status-error); }')).toEqual([]);
    // …nor the sibling tokens…
    expect(redTextSelectors('.a { color: var(--status-error-text); }')).toEqual([]);
    expect(redTextSelectors('.a { color: var(--status-error-soft); }')).toEqual([]);
    // …and a leak quoted inside a COMMENT is a mention, not a use.
    expect(redTextSelectors('/* .a { color: var(--status-error); } */')).toEqual([]);
    // The var() FALLBACK form and the legacy `--danger` alias (tokens.css:284 aliases it
    // to the same fill red) are BOTH fill-red-as-text and must be seen.
    expect(redTextSelectors('.a { color: var(--status-error, #e5484d); }')).toEqual(['.a']);
    expect(redTextSelectors('.a { color: var(--danger); }')).toEqual(['.a']);
  });

  it('sees a leak inside @media/@supports, but NOT one beside a native-nested block', () => {
    // Wrapping at-rules are the nesting shape this tree actually uses, and they are seen:
    expect(redTextSelectors('@media (min-width: 10px) { .a { color: var(--status-error); } }')) //
      .toEqual(['.a']);
    expect(redTextSelectors('@supports (color: red) { .a { color: var(--status-error); } }')) //
      .toEqual(['.a']);
    // DISCLOSED BLIND SPOT, pinned here so the limitation is executable rather than
    // folklore: the `([^{}]+)\{([^{}]*)\}` tokenizer — inherited verbatim from the H7
    // editorial-serif guard at :763 — cannot see a declaration in a PARENT rule that also
    // contains a native-nested `&` block. Measured over the 65 sheets: 0 use native
    // nesting, so this is latent, not live. Settling change: tokenize by brace depth
    // instead of a flat `[^{}]` pair, then DELETE this expectation (it will go red).
    expect(redTextSelectors('.a {\n  color: var(--status-error);\n  &:hover { color: blue; }\n}')) //
      .toEqual([]);
  });

  it('the FILL detector cannot count a fill that is in a DIFFERENT rule', () => {
    // `[^;]*` would cross a `}`, so a sheet whose background and red text live in two
    // separate rules would falsely count as a fill consumer — silently restoring slack in
    // the only assertion protecting the fills from a bulk sweep.
    expect(FILL_USE.test('.a { background: var(--status-error); }')).toBe(true);
    expect(FILL_USE.test('.a { border: 1px solid var(--status-error); }')).toBe(true);
    expect(FILL_USE.test('.a { background: red }\n.b { color: var(--status-error) }')).toBe(false);
  });

  it('scans the real sheet set, and the AA-safe token is genuinely in use', () => {
    // A dead scan over zero files would vacuously pass. Pin a file floor, and pin that
    // the red ladder really is present in this tree — so an empty offender list reads
    // as "migrated", never as "there is no red text here".
    expect(cssFiles.length).toBeGreaterThan(20);
    const consumers = cssFiles.filter((f) =>
      stripComments(readFileSync(f, 'utf8')).includes('color: var(--status-error-text)'),
    );
    expect(consumers.length).toBeGreaterThan(20);
  });

  it('every bare `color: var(--status-error)` site is on the allowlist', () => {
    const offenders: string[] = [];
    for (const file of cssFiles) {
      for (const sel of redTextSelectors(readFileSync(file, 'utf8'))) {
        if (!RED_TEXT_ALLOWLIST.includes(sel)) {
          offenders.push(`${sel}  (${relative(RENDERER_SRC, file).replace(/\\/g, '/')})`);
        }
      }
    }
    // The message names the offender AND the fix, so a failure is actionable without
    // opening this file.
    expect(
      offenders,
      'Bare `color: var(--status-error)` — the solid FILL red used as a red STRING. ' +
        'Measured: 4.12:1 on --surface-raised and 3.17:1 on --surface-hover, both under ' +
        'the 4.5:1 WCAG AA floor. Route red TEXT through var(--status-error-text); keep ' +
        '--status-error for background-color / border-color. If a site genuinely clears ' +
        'AA on its own background, add its selector to RED_TEXT_ALLOWLIST with the ' +
        'measured ratio and the background you measured against.',
    ).toEqual([]);
  });

  it('the allowlist has no dead entries (it tracks the tree, not history)', () => {
    // The other direction: an allowlisted selector that no longer sets red text is
    // stale permission, and stale permission is how an allowlist rots into a rubber
    // stamp. (Mirrors the editorial-serif guard at :805.)
    const live = cssFiles.flatMap((f) => redTextSelectors(readFileSync(f, 'utf8')));
    expect(deadRedTextEntries(RED_TEXT_ALLOWLIST, live)).toEqual([]);
  });

  it('the dead-entry detector FIRES on stale permission (both-states control)', () => {
    // The assertion above passes trivially while RED_TEXT_ALLOWLIST is empty, so the
    // mechanism is exercised on synthetic input instead: a live entry stays silent, a
    // stale one is reported. This is what will police the FIRST real addition.
    expect(deadRedTextEntries(['.live'], ['.live'])).toEqual([]);
    expect(deadRedTextEntries(['.gone'], ['.live'])).toEqual(['.gone']);
    expect(deadRedTextEntries(['.gone', '.live'], ['.live'])).toEqual(['.gone']);
  });

  it('keeps the FILL red in use as a fill — the migration is text-only', () => {
    // Zero-regression check on the other half of the token split. --status-error must
    // still be consumed as a background / border; if a bulk find-and-replace had swept
    // the fills too (the obvious way to make the guard above green by accident), the
    // FAILED-dot, progress fills and danger borders would all have gone with it.
    const fills = cssFiles.filter((f) => FILL_USE.test(stripComments(readFileSync(f, 'utf8'))));
    expect(fills.length).toBeGreaterThanOrEqual(19);
  });
});
