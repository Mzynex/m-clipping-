// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { CaptionPreferences, type SettingsBridge } from './CaptionPreferences';
import { PREFERENCE_KEYS } from '../lib/captionPreferences';
import { AUTO_DETECT } from '../lib/languages';

(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true;

interface Deferred<T> {
  promise: Promise<T>;
  resolve: (v: T) => void;
  reject: (e: unknown) => void;
}
function deferred<T>(): Deferred<T> {
  let resolve!: (v: T) => void;
  let reject!: (e: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

const flush = async (): Promise<void> => {
  await act(async () => {
    await Promise.resolve();
  });
};

describe('<CaptionPreferences />', () => {
  let container: HTMLDivElement;
  let root: Root;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    root = createRoot(container);
  });
  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  function mountWith(rpc: SettingsBridge): void {
    act(() => root.render(<CaptionPreferences rpc={rpc} />));
  }

  const swatch = (id: string): HTMLButtonElement =>
    container.querySelector(`[data-style="${id}"]`) as HTMLButtonElement;
  const subSelect = (): HTMLSelectElement =>
    container.querySelector('select[aria-label="Default subtitle delivery"]') as HTMLSelectElement;
  const saveBtn = (): HTMLButtonElement =>
    [...container.querySelectorAll('button')].find((b) =>
      (b.textContent ?? '').startsWith('Sav'),
    ) as HTMLButtonElement;
  const polishToggle = (): HTMLInputElement =>
    container.querySelector('#prefs-caption-polish') as HTMLInputElement;
  const speakersToggle = (): HTMLInputElement =>
    container.querySelector('#prefs-caption-speakers') as HTMLInputElement;

  it('offers Auto-detect as the default language, and can persist it', async () => {
    // The default caption language is a transcription SOURCE hint, so auto-detect
    // is exactly the meaningful choice — it used to be suppressed here
    // (includeAuto={false}) AND unrepresentable in persisted state (audit §2.1).
    const rpc: SettingsBridge = { get: vi.fn().mockResolvedValue({}), set: vi.fn() };
    mountWith(rpc);
    await flush();
    const lang = container.querySelector(
      'select[aria-label="Default language"]',
    ) as HTMLSelectElement;
    const codes = [...lang.querySelectorAll('option')].map((o) => o.value);
    expect(codes).toContain(AUTO_DETECT);
    // ...and a previously-unreachable language is now offered here too.
    expect(codes).toContain('ro');
    act(() => {
      lang.value = AUTO_DETECT;
      lang.dispatchEvent(new Event('change', { bubbles: true }));
    });
    expect(lang.value).toBe(AUTO_DETECT);
    await act(async () => {
      saveBtn().click();
      await Promise.resolve();
    });
    expect(rpc.set).toHaveBeenCalledWith(
      expect.objectContaining({ [PREFERENCE_KEYS.language]: AUTO_DETECT }),
    );
  });

  it('warns when the persisted ASR engine cannot transcribe the chosen default language', async () => {
    // The engine lives in the SAME settings payload this panel already reads, so
    // the D4 engine-specific caveat costs no extra rpc. Parakeet covers 25
    // European languages; Thai is not one of them, and offering it silently is
    // exactly the "language that will fail" case.
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({ asrEngine: 'parakeet', [PREFERENCE_KEYS.language]: 'th' }),
      set: vi.fn(),
    };
    mountWith(rpc);
    await flush();
    const note = container.querySelector('.lang-select__capability')?.textContent ?? '';
    expect(note).toContain('Parakeet');
    expect(note).toContain('Thai');
    expect(note).toContain('Whisper');
  });

  it('shows no engine warning when the persisted engine does cover the language', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({ asrEngine: 'parakeet', [PREFERENCE_KEYS.language]: 'ro' }),
      set: vi.fn(),
    };
    mountWith(rpc);
    await flush();
    expect(container.querySelector('.lang-select__capability')).toBeNull();
  });

  it('loads + reflects persisted preferences', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({
        [PREFERENCE_KEYS.style]: 'hormozi',
        [PREFERENCE_KEYS.subtitleMode]: 'sidecar',
        [PREFERENCE_KEYS.language]: 'pt',
        [PREFERENCE_KEYS.captionPolish]: true,
      }),
      set: vi.fn(),
    };
    mountWith(rpc);
    await flush();
    expect(swatch('hormozi').getAttribute('aria-pressed')).toBe('true');
    expect(subSelect().value).toBe('sidecar');
    expect(polishToggle().checked).toBe(true);
    expect(speakersToggle().checked).toBe(false);
  });

  it('toggles + persists the caption-quality flags', async () => {
    const set = vi.fn().mockResolvedValue({});
    const rpc: SettingsBridge = { get: vi.fn().mockResolvedValue({}), set };
    mountWith(rpc);
    await flush();
    // Off by default (nothing persisted).
    expect(polishToggle().checked).toBe(false);
    expect(speakersToggle().checked).toBe(false);
    // React binds checkbox onChange to the CLICK event (not 'change'), so click.
    act(() => polishToggle().click());
    act(() => speakersToggle().click());
    expect(polishToggle().checked).toBe(true);
    expect(speakersToggle().checked).toBe(true);
    await act(async () => {
      saveBtn().click();
      await Promise.resolve();
    });
    expect(set).toHaveBeenCalledWith(
      expect.objectContaining({
        [PREFERENCE_KEYS.captionPolish]: true,
        [PREFERENCE_KEYS.captionSpeakerLabels]: true,
      }),
    );
  });

  it('shows an error when loading fails', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockRejectedValue(new Error('boom')),
      set: vi.fn(),
    };
    mountWith(rpc);
    await flush();
    expect(container.querySelector('.caption-prefs__error')?.textContent).toContain('boom');
  });

  it('saves the current preferences (and shows the in-flight state)', async () => {
    const d = deferred<Record<string, unknown>>();
    const set = vi.fn().mockReturnValue(d.promise);
    const rpc: SettingsBridge = { get: vi.fn().mockResolvedValue({}), set };
    mountWith(rpc);
    await flush();
    // Change the style first so the save carries it.
    act(() => swatch('neon').click());
    act(() => saveBtn().click());
    // While the set promise is pending the button is busy.
    expect(saveBtn().textContent).toBe('Saving…');
    expect(saveBtn().disabled).toBe(true);
    await act(async () => {
      d.resolve({});
      await Promise.resolve();
    });
    expect(set).toHaveBeenCalledWith(expect.objectContaining({ [PREFERENCE_KEYS.style]: 'neon' }));
    expect(container.querySelector('.caption-prefs__status')?.textContent).toBe(
      'Preferences saved.',
    );
  });

  it('shows an error when saving fails (non-Error rejection)', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({}),
      // A plain-string rejection exercises the non-Error errText path.
      set: vi.fn().mockRejectedValue('nope-string'),
    };
    mountWith(rpc);
    await flush();
    await act(async () => {
      saveBtn().click();
      await Promise.resolve();
    });
    expect(container.querySelector('.caption-prefs__error')?.textContent).toContain('nope-string');
  });

  it('changes subtitle mode + language', async () => {
    const rpc: SettingsBridge = { get: vi.fn().mockResolvedValue({}), set: vi.fn() };
    mountWith(rpc);
    await flush();
    act(() => {
      subSelect().value = 'softmux';
      subSelect().dispatchEvent(new Event('change', { bubbles: true }));
    });
    expect(subSelect().value).toBe('softmux');
    const lang = container.querySelector(
      'select[aria-label="Default language"]',
    ) as HTMLSelectElement;
    act(() => {
      lang.value = 'fr';
      lang.dispatchEvent(new Event('change', { bubbles: true }));
    });
    expect(lang.value).toBe('fr');
  });

  it('shows a "No captions" sample for the none style', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({ [PREFERENCE_KEYS.style]: 'none' }),
      set: vi.fn(),
    };
    mountWith(rpc);
    await flush();
    expect(container.querySelector('.caption-prefs__sample')?.textContent).toBe('No captions');
  });

  it('moves the default position box by dragging it', async () => {
    const set = vi.fn().mockResolvedValue({});
    const rpc: SettingsBridge = { get: vi.fn().mockResolvedValue({}), set };
    mountWith(rpc);
    await flush();
    const frame = container.querySelector('.caption-box-frame') as HTMLElement;
    frame.getBoundingClientRect = () =>
      ({
        width: 100,
        height: 100,
        top: 0,
        left: 0,
        right: 100,
        bottom: 100,
        x: 0,
        y: 0,
      }) as DOMRect;
    const boxEl = container.querySelector('[data-testid="caption-box"]') as HTMLElement;
    const fire = (type: string, x: number, y: number): void => {
      const ev = new MouseEvent(type, { bubbles: true, clientX: x, clientY: y });
      Object.defineProperty(ev, 'pointerId', { value: 1 });
      act(() => boxEl.dispatchEvent(ev));
    };
    fire('pointerdown', 0, 0);
    fire('pointermove', 0, 10); // move down 0.1
    await act(async () => {
      saveBtn().click();
      await Promise.resolve();
    });
    const savedBox = set.mock.calls[0][0][PREFERENCE_KEYS.box] as { y: number };
    expect(savedBox.y).toBeGreaterThan(0.76);
  });

  it('ignores a late load resolve after unmount', async () => {
    const d = deferred<Record<string, unknown>>();
    const rpc: SettingsBridge = { get: () => d.promise, set: vi.fn() };
    mountWith(rpc);
    act(() => root.unmount());
    await act(async () => {
      d.resolve({ [PREFERENCE_KEYS.style]: 'neon' });
      await Promise.resolve();
    });
    // No throw / no swatch (unmounted) — the alive guard skipped setState.
    expect(container.querySelector('[data-style="neon"]')).toBeNull();
  });

  it('ignores a late load error after unmount', async () => {
    const d = deferred<Record<string, unknown>>();
    const rpc: SettingsBridge = { get: () => d.promise, set: vi.fn() };
    mountWith(rpc);
    act(() => root.unmount());
    await act(async () => {
      d.reject(new Error('late'));
      await Promise.resolve();
    });
    expect(container.querySelector('.caption-prefs__error')).toBeNull();
  });

  it('does not paint the "No captions" sample with the transparent none fill', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({ [PREFERENCE_KEYS.style]: 'none' }),
      set: vi.fn(),
    };
    mountWith(rpc);
    await flush();
    const sample = container.querySelector('.caption-prefs__sample') as HTMLElement;
    // Control (green before AND after) — the none style really is selected.
    expect(sample.textContent).toBe('No captions');
    // DEFECT: NONE_VISUAL.activeColor is the literal 'transparent'
    // (captionTemplates.ts), so the position preview's own explanatory label was
    // painted at zero alpha. No inline colour => it inherits --text-primary.
    // NOT asserted: the resolved colour — jsdom applies no stylesheet, so
    // legibility is a Playwright/visual claim, never a green unit test.
    expect(sample.style.color).toBe('');
    expect(sample.classList.contains('caption-prefs__sample--none')).toBe(true);
  });

  it('clears the saved confirmation on any later edit', async () => {
    const rpc: SettingsBridge = {
      get: vi.fn().mockResolvedValue({}),
      set: vi.fn().mockResolvedValue({}),
    };
    mountWith(rpc);
    await flush();
    const status = (): Element | null => container.querySelector('.caption-prefs__status');
    const save = async (): Promise<void> => {
      await act(async () => {
        saveBtn().click();
        await Promise.resolve();
      });
    };

    // Control (already pinned by the save test above) — a broken mount/save path
    // fails HERE, not on the defect assertions below.
    await save();
    expect(status()?.textContent).toBe('Preferences saved.');

    // DEFECT: `Preferences saved.` is only ever cleared by the NEXT save, so the
    // success live region keeps asserting a state that no longer matches disk.
    act(() => swatch('neon').click());
    expect(status()).toBeNull();

    // A structurally different handler (a checkbox, not the style picker) too, so
    // the regression is not pinned to one of the six edit paths.
    await save();
    expect(status()?.textContent).toBe('Preferences saved.');
    act(() => polishToggle().click());
    expect(status()).toBeNull();
  });

  it('scopes the caption-quality promise to the surfaces those flags reach', async () => {
    const rpc: SettingsBridge = { get: vi.fn().mockResolvedValue({}), set: vi.fn() };
    mountWith(rpc);
    await flush();
    // Control (green before AND after the fix) — the panel mounted with its five
    // groups and both caption-quality toggles. A failure HERE is a setup break.
    expect(container.querySelectorAll('.caption-prefs__group')).toHaveLength(5);
    expect(polishToggle()).not.toBeNull();

    // DEFECT (a) — the "Caption quality" group is a bare <div> with an <h3>, so a
    // scope disclosure cannot be programmatically associated with it.
    const group = container.querySelector('.caption-prefs__group[role="group"]');
    expect(group).not.toBeNull();
    const quality = group as HTMLElement;
    expect(
      document.getElementById(quality.getAttribute('aria-labelledby') ?? '')?.textContent,
    ).toBe('Caption quality');
    // It owns exactly the two controls the panel-wide promise is false for.
    expect(quality.contains(polishToggle())).toBe(true);
    expect(quality.contains(speakersToggle())).toBe(true);

    // DEFECT (b) — no scope text exists anywhere in the panel. captionPolish /
    // captionSpeakerLabels are read only by subtitles.generate, which the
    // Caption, Subtitles and Recipes surfaces reach — never the shorts export.
    const scope =
      document.getElementById(quality.getAttribute('aria-describedby') ?? '')?.textContent ?? '';
    expect(scope).toContain('Caption');
    expect(scope).toContain('Subtitles');
    expect(scope).toContain('Recipes');

    // DEFECT (c) — the panel hint made a blanket "every new short" promise over
    // all six controls; it must now enumerate only the four that do seed a short.
    const hint = container.querySelector('.caption-prefs__hint')?.textContent ?? '';
    expect(hint).toContain('seed every new short');
    expect(hint).toMatch(/style/i);
    expect(hint).toMatch(/position/i);
    expect(hint).toMatch(/subtitle/i);
    expect(hint).toMatch(/language/i);
  });

  it('defaults to the live client settings rpc when none injected', async () => {
    // Render WITHOUT an rpc prop -> uses client.settings, which reads window.api.
    const win = globalThis as unknown as { window?: { api?: unknown } };
    const prev = win.window?.api;
    win.window = win.window ?? {};
    (win.window as { api?: unknown }).api = {
      rpc: vi.fn().mockResolvedValue({ [PREFERENCE_KEYS.style]: 'bold' }),
    };
    act(() => root.render(<CaptionPreferences />));
    await flush();
    expect(swatch('bold').getAttribute('aria-pressed')).toBe('true');
    (win.window as { api?: unknown }).api = prev;
  });
});
