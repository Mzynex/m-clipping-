// ReadinessRollup.test.tsx — the unified readiness roll-up consumer (WU-14).
//
// Wires `readiness.summary` (WU-8) into a reusable section that renders one
// <ReadinessBadge /> (WU-9) per capability with its capability-tied action
// button. Pins the falsifiable WU-14 acceptance: N badges for N items, each with
// its action button; the reused in-flight skeleton shows before data resolves;
// actions forward to the parent; failures degrade to a quiet error (never crash).
//
// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';

import { ReadinessRollup } from './ReadinessRollup';
import { READINESS_LABEL } from './readinessMeta';
import type { ReadinessAction, ReadinessItem } from '../lib/rpc';

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement;
let root: Root;

beforeEach(() => {
  container = document.createElement('div');
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => {
    root.unmount();
  });
  container.remove();
});

/** A minimal typed client stub exposing only `readiness.summary`. */
function makeClient(summary: () => Promise<{ items: ReadinessItem[] }>) {
  return { readiness: { summary: vi.fn(summary) } } as unknown as Parameters<
    typeof ReadinessRollup
  >[0]['rpcClient'];
}

async function flush(turns = 4): Promise<void> {
  await act(async () => {
    for (let i = 0; i < turns; i += 1) await Promise.resolve();
  });
}

function makeItem(over: Partial<ReadinessItem> = {}): ReadinessItem {
  return {
    capability: 'tier1-multimodal',
    label: 'Tier 1 multimodal',
    status: 'ready',
    blockedBy: '',
    action: null,
    ...over,
  };
}

describe('<ReadinessRollup /> — WU-14 wiring', () => {
  it('renders one ReadinessBadge per readiness.summary item', async () => {
    const items = [
      makeItem({ capability: 'a', label: 'Captions', status: 'ready' }),
      makeItem({
        capability: 'b',
        label: 'Vision',
        status: 'needsDownload',
        blockedBy: 'saliency missing',
        action: { kind: 'assets.ensure', assets: ['saliency'] },
      }),
      makeItem({
        capability: 'c',
        label: 'Translation',
        status: 'needsKey',
        action: { kind: 'openProviders' },
      }),
    ];
    const rpcClient = makeClient(() => Promise.resolve({ items }));

    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    await flush();

    const badges = container.querySelectorAll('[role="status"]');
    expect(badges.length).toBe(3);
    expect(badges[0].textContent).toBe(READINESS_LABEL.ready);
    expect(badges[1].textContent).toBe(READINESS_LABEL.needsDownload);
    expect(badges[2].textContent).toBe(READINESS_LABEL.needsKey);
    // One row per item, labelled by the capability name.
    expect(container.textContent).toContain('Captions');
    expect(container.textContent).toContain('Vision');
    expect(container.textContent).toContain('Translation');
  });

  it('renders an action button only for items that carry a fix action', async () => {
    const items = [
      makeItem({ capability: 'ready', label: 'Ready cap', status: 'ready', action: null }),
      makeItem({
        capability: 'fix',
        label: 'Vision',
        status: 'needsDownload',
        action: { kind: 'assets.ensure', assets: ['saliency'] },
      }),
    ];
    const rpcClient = makeClient(() => Promise.resolve({ items }));

    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    await flush();

    const buttons = container.querySelectorAll('button.readiness-badge__action');
    expect(buttons.length).toBe(1);
    expect(buttons[0].getAttribute('aria-label')).toBe('Download the Vision model');
  });

  it('shows the reused in-flight skeleton before the data resolves', async () => {
    let resolve: (v: { items: ReadinessItem[] }) => void = () => {};
    const rpcClient = makeClient(
      () =>
        new Promise<{ items: ReadinessItem[] }>((res) => {
          resolve = res;
        }),
    );

    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    // Mid-flight: the reused skeleton (jobqueue empty convention) is showing.
    expect(container.querySelector('.jobqueue__empty')).not.toBeNull();
    expect(container.querySelectorAll('[role="status"]').length).toBe(0);

    await act(async () => {
      resolve({ items: [makeItem({ label: 'Captions' })] });
    });
    await flush();

    expect(container.querySelector('.jobqueue__empty')).toBeNull();
    expect(container.querySelectorAll('[role="status"]').length).toBe(1);
  });

  it('forwards a badge action click to onAction', async () => {
    const action: ReadinessAction = { kind: 'openProviders' };
    const items = [makeItem({ label: 'Translation', status: 'needsKey', action })];
    const rpcClient = makeClient(() => Promise.resolve({ items }));
    let received: ReadinessAction | null = null;

    await act(async () => {
      root.render(
        <ReadinessRollup
          rpcClient={rpcClient}
          onAction={(a) => {
            received = a;
          }}
        />,
      );
    });
    await flush();

    const button = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
    await act(async () => {
      button.click();
    });
    expect(received).toBe(action);
  });

  it('renders an empty-state line when there are no readiness items', async () => {
    const rpcClient = makeClient(() => Promise.resolve({ items: [] }));
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    await flush();
    expect(container.querySelector('.jobqueue__empty')).toBeNull();
    expect(container.querySelectorAll('[role="status"]').length).toBe(0);
    expect(container.textContent).toContain('Nothing to report');
  });

  it('tolerates a result with no items field (treats it as empty)', async () => {
    const rpcClient = makeClient(() => Promise.resolve({}) as Promise<{ items: ReadinessItem[] }>);
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    await flush();
    expect(container.querySelectorAll('[role="status"]').length).toBe(0);
    expect(container.textContent).toContain('Nothing to report');
  });

  it('surfaces a load error without crashing (Error instance)', async () => {
    const rpcClient = makeClient(() => Promise.reject(new Error('sidecar down')));
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    await flush();
    expect(container.querySelector('[role="alert"]')?.textContent).toContain('sidecar down');
    expect(container.querySelector('.jobqueue__empty')).toBeNull();
  });

  it('stringifies a non-Error load rejection', async () => {
    const rpcClient = makeClient(() => Promise.reject('plain failure'));
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    await flush();
    expect(container.querySelector('[role="alert"]')?.textContent).toContain('plain failure');
  });

  it('renders a custom title when provided', async () => {
    const rpcClient = makeClient(() => Promise.resolve({ items: [makeItem()] }));
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} title="What works right now" />);
    });
    await flush();
    expect(container.textContent).toContain('What works right now');
  });

  it('degrades to an inline error (no thrown-through blank) when window.api is missing', async () => {
    // WU2 resilience: with no injected rpcClient the component uses the real
    // `client`, whose bridge() throws SYNCHRONOUSLY when window.api is undefined.
    // That sync throw escapes the effect's `.catch()`; the sync-safe guard must
    // surface it inline instead of letting it unmount the tree.
    expect((globalThis as { window?: { api?: unknown } }).window?.api).toBeUndefined();
    await act(async () => {
      root.render(<ReadinessRollup />);
    });
    await flush();
    const alert = container.querySelector('[role="alert"]');
    expect(alert).not.toBeNull();
    expect(alert?.textContent).toContain('window.api');
    expect(container.querySelector('.jobqueue__empty')).toBeNull();
  });

  // ---- F36: the roll-up must re-read after its OWN fix action ---------------

  it('disables + marks the action busy while the parent action is in flight (F36)', async () => {
    const items = [
      makeItem({
        capability: 'vis',
        label: 'Vision',
        status: 'needsDownload',
        action: { kind: 'assets.ensure', assets: ['saliency'] },
      }),
    ];
    const rpcClient = makeClient(() => Promise.resolve({ items }));
    await act(async () => {
      // A never-settling parent promise keeps the action in flight.
      root.render(
        <ReadinessRollup rpcClient={rpcClient} onAction={() => new Promise<void>(() => {})} />,
      );
    });
    await flush();
    const btn = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
    expect(btn.disabled).toBe(false);
    await act(async () => {
      btn.click();
    });
    expect(btn.disabled).toBe(true);
    expect(btn.getAttribute('aria-busy')).toBe('true');
  });

  it('re-reads readiness.summary after its own fix action resolves (F36)', async () => {
    let call = 0;
    const rpcClient = makeClient(() => {
      call += 1;
      return Promise.resolve({
        items: [
          makeItem({
            capability: 'vis',
            label: 'Vision',
            status: call === 1 ? 'needsDownload' : 'ready',
            action: call === 1 ? { kind: 'assets.ensure', assets: ['saliency'] } : null,
          }),
        ],
      });
    });
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} onAction={() => Promise.resolve()} />);
    });
    await flush();
    expect(container.querySelector('[data-readiness]')?.getAttribute('data-readiness')).toBe(
      'needsDownload',
    );
    const btn = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
    await act(async () => {
      btn.click();
    });
    await flush();
    // The badge reflects the POST-fix truth without leaving + re-entering the tab.
    expect(container.querySelector('[data-readiness]')?.getAttribute('data-readiness')).toBe(
      'ready',
    );
    expect(call).toBe(2);
  });

  it('clears busy and still re-reads when the parent action REJECTS (F36)', async () => {
    let call = 0;
    const rpcClient = makeClient(() => {
      call += 1;
      return Promise.resolve({
        items: [
          makeItem({
            capability: 'vis',
            label: 'Vision',
            status: 'needsDownload',
            action: { kind: 'assets.ensure', assets: ['saliency'] },
          }),
        ],
      });
    });
    await act(async () => {
      root.render(
        <ReadinessRollup
          rpcClient={rpcClient}
          onAction={() => Promise.reject(new Error('ensure blew up'))}
        />,
      );
    });
    await flush();
    const btn = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
    await act(async () => {
      btn.click();
    });
    await flush();
    const after = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
    expect(after.disabled).toBe(false);
    expect(after.getAttribute('aria-busy')).toBe('false');
    // The parent owns its own error surface; the roll-up must not invent one.
    expect(container.querySelector('[role="alert"]')).toBeNull();
    expect(call).toBe(2);
  });

  it('does NOT busy-flash or re-read for navigation-only action kinds (F36)', async () => {
    let call = 0;
    const kinds: ReadinessAction[] = [{ kind: 'openProviders' }, { kind: 'setConsent' }];
    for (const action of kinds) {
      const rpcClient = makeClient(() => {
        call += 1;
        return Promise.resolve({
          items: [makeItem({ capability: 'x', label: 'Translation', status: 'needsKey', action })],
        });
      });
      const seen: ReadinessAction[] = [];
      await act(async () => {
        root.render(<ReadinessRollup rpcClient={rpcClient} onAction={(a) => void seen.push(a)} />);
      });
      await flush();
      const before = call;
      const btn = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
      await act(async () => {
        btn.click();
      });
      await flush();
      // Forwarded, but these NAVIGATE AWAY (Settings.goTo unmounts this tree) —
      // a refresh there is a wasted RPC on a dying tree, and the busy flash lies.
      expect(seen).toEqual([action]);
      expect(call).toBe(before);
      expect(btn.disabled).toBe(false);
      await act(async () => {
        root.unmount();
      });
      root = createRoot(container);
    }
  });

  it('drops a post-action refresh after unmount (no setState on a dead tree)', async () => {
    let release: (() => void) | undefined;
    let call = 0;
    const rpcClient = makeClient(() => {
      call += 1;
      return Promise.resolve({
        items: [
          makeItem({
            capability: 'vis',
            label: 'Vision',
            status: 'needsDownload',
            action: { kind: 'assets.ensure', assets: ['saliency'] },
          }),
        ],
      });
    });
    await act(async () => {
      root.render(
        <ReadinessRollup
          rpcClient={rpcClient}
          onAction={() => new Promise<void>((res) => void (release = () => res()))}
        />,
      );
    });
    await flush();
    const btn = container.querySelector('button.readiness-badge__action') as HTMLButtonElement;
    await act(async () => {
      btn.click();
    });
    const callsAtUnmount = call;
    await act(async () => {
      root.unmount();
    });
    await act(async () => {
      release?.();
      await Promise.resolve();
    });
    // The alive guard drops both the setPending and the refetch.
    expect(call).toBe(callsAtUnmount);
    root = createRoot(container);
  });

  it('ignores a late resolve after unmount (no state update warning)', async () => {
    let resolve: (v: { items: ReadinessItem[] }) => void = () => {};
    const rpcClient = makeClient(
      () =>
        new Promise<{ items: ReadinessItem[] }>((res) => {
          resolve = res;
        }),
    );
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={rpcClient} />);
    });
    // Unmount before the summary resolves.
    await act(async () => {
      root.unmount();
    });
    // Resolving now must be a no-op (the alive guard drops the result).
    await act(async () => {
      resolve({ items: [makeItem()] });
    });
    expect(container.querySelectorAll('[role="status"]').length).toBe(0);
    // Re-create the root so afterEach's unmount is safe.
    root = createRoot(container);
  });
});

describe('<ReadinessRollup /> — unmount-abort arm (aliveRef)', () => {
  it('drops a summary rejection that lands after unmount', async () => {
    // The aliveRef guard must also cover the .catch arm: an `assets.ensure`
    // refresh outliving the panel must not setError on a dead root.
    let reject!: (e: unknown) => void;
    const client = makeClient(() => new Promise((_, rej) => (reject = rej)));
    await act(async () => {
      root.render(<ReadinessRollup rpcClient={client} />);
    });
    await act(async () => {
      root.unmount();
    });
    await act(async () => {
      reject(new Error('late readiness boom'));
      await Promise.resolve();
    });
  });
});
