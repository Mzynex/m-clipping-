// ModelsSystemPanel.tsx — the "Models & System" graphics-settings-style panel.
//
// Opt-in hardware analysis for the Phase-8 moment-finding pipeline: the user
// runs "Analyze my system", which calls the cheap direct RPCs system.probe +
// system.advisor (+ asr.engines + assets.list for download gating). It then
// renders, in one graphics-settings surface:
//   * a hardware header with VRAM / RAM availability BARS + CPU / GPU chips,
//   * a recommended-preset banner with Apply,
//   * a Tier-0/1/2 selector (radio cards with will-it-run verdicts),
//   * a per-model grid (quality-vs-cost, VRAM, size, license, gated Download),
//   * the advisor notes strip (verbatim manifest alerts),
//   * an ASR + diarize backend selector,
//   * a first-run 3-step onboarding overlay (a clear 101).
//
// Consumes the FROZEN window.api bridge through the typed `client`/`rpc` from
// lib/rpc. All settings flow through settings.get/set — no new store.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import '../features/panels.css';
import './modelsSystem.css';
import {
  client,
  hasApi,
  onJobDone,
  type AdvisorReport,
  type AsrEngine,
  type AssetInfo,
  type CatalogResponse,
  type ComponentStatus,
  type HardwareInfo,
  type LocalModelPlan,
  type ModelsOverview,
  type OpenRouterUsageRow,
  type ProviderUsageAvailability as UsageAvailabilityRow,
  type Recommendation,
  type RoutingBlock,
  type RoutingPolicy,
  type UsageRow,
} from '../lib/rpc';
import { componentAsset, presetLabel, presetTier } from '../components/advisorMeta';
import { ResourceBar } from '../components/ResourceBar';
import { TierCard } from '../components/TierCard';
import { ModelCard } from '../components/ModelCard';
import { ModelsOnboarding } from '../components/ModelsOnboarding';
import { UsageBars } from '../components/UsageBar';
import { DeviceStatusStrip } from '../components/DeviceStatusStrip';
import { DeviceModelReco } from '../components/DeviceModelReco';
import { ReasonStrip } from '../components/ReasonStrip';
import { AdvancedModels } from '../components/AdvancedModels';
import { RoutingOverrideTable } from '../components/RoutingOverrideTable';
import { AlignModelSelect } from '../components/AlignModelSelect';
import { LocalRunners } from '../components/LocalRunners';
import { OpenRouterUsage } from '../components/OpenRouterUsage';
import { ProviderUsageAvailability } from '../components/ProviderUsageAvailability';
import { PresetPicker } from '../components/PresetPicker';
import { FirstRunChooser } from '../components/FirstRunChooser';
import { ReadinessRollup } from '../components/ReadinessRollup';
import type { ReadinessAction } from '../lib/rpc';
import {
  DEFAULT_JOB_TIMEOUT_MS,
  JobAbortedError,
  waitForJobDone,
  type JobDoneCapable,
} from '../features/_api';

// --- pure helpers (exported for tests) -------------------------------------

/** Error text from an unknown thrown value (mirrors the sibling panels). */
export function errText(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

/**
 * M5: fold a freshly-persisted RoutingPolicy back into the overview (immutably).
 * A null overview (never composed) is returned unchanged so the override table —
 * which only renders with an overview present — has a total, branch-tested merge.
 */
export function mergeOverviewRoutingPolicy(
  prev: ModelsOverview | null,
  routingPolicy: RoutingPolicy,
): ModelsOverview | null {
  return prev ? { ...prev, routingPolicy } : prev;
}

/**
 * The quality fraction (0..1) for a model card's quality mini-bar: which tier
 * the component belongs to, normalized over the max tier. A higher-tier model
 * contributes "more quality". Components not in any tier (speech extras) map to
 * the mid value so the bar is never empty/misleading.
 */
export function qualityFraction(componentName: string, report: AdvisorReport): number {
  const maxTier = report.tiers.reduce((m, t) => Math.max(m, t.tier), 0) || 1;
  const owning = report.tiers.find((t) => t.components.includes(componentName));
  if (!owning) return 0.5;
  return owning.tier / maxTier;
}

/**
 * F34: the terminal `assets.ensure` job payload, normalised. The sidecar returns
 * `{installed, failed, assets}` (`assets/manager.py:749`) — `assets` is the SAME
 * `list_assets()` rows `assets.list` serves, so a successful job already carries
 * the refreshed state and needs no second round-trip. Both fields are normalised
 * to a non-optional shape here so the caller has no per-field nullish branches.
 */
export interface EnsureDone {
  /** Per-item failures a SUCCESS payload can still carry (partial failure). */
  failed: { name: string; error: string }[];
  /** The refreshed asset rows, or null when the payload did not carry them. */
  assets: AssetInfo[] | null;
}

/**
 * Read the `assets.ensure` terminal payload off a `job.done` result.
 *
 * `job.done` is UNTRUSTED wire data, so every field is shape-checked (the same
 * `Array.isArray` discipline the panel's other ingest points use). Returns null
 * for a non-object result — including the `null` `waitForJobDone` resolves when
 * the host exposes no `job.done` bridge (`_api.ts:236-238`).
 */
export function extractEnsureDone(result: unknown): EnsureDone | null {
  if (!result || typeof result !== 'object') return null;
  const raw = result as { failed?: unknown; assets?: unknown };
  return {
    failed: Array.isArray(raw.failed) ? (raw.failed as EnsureDone['failed']) : [],
    assets: Array.isArray(raw.assets) ? (raw.assets as AssetInfo[]) : null,
  };
}

/**
 * F34: announce the per-item failures a SUCCESS ensure payload carries.
 * `manager.py:744` raises only when NOTHING installed, so a partial failure
 * arrives as a successful `job.done` with `failed:[…]` — silent without this.
 */
export function ensureFailureText(failed: EnsureDone['failed']): string {
  return `Some downloads failed: ${failed.map((f) => `${f.name} (${f.error})`).join('; ')}`;
}

/**
 * F34: the real `job.done` bridge, or an inert stub when no preload bridge exists.
 *
 * `onJobDone` reaches through `bridge()`, which THROWS without `window.api`, so
 * handing it to `waitForJobDone` unguarded would turn every bridgeless host (and
 * every test in this file) into a REJECTED wait instead of the intended degraded
 * arm. `hasApi()` keeps that arm reachable: an empty object has no `onJobDone`,
 * so `waitForJobDone` resolves null at once (`_api.ts:236-238`) and the caller
 * falls back to a plain `assets.list` refresh.
 */
export function defaultJobBridge(): JobDoneCapable {
  /* v8 ignore next -- hasApi() is TRUE only in the packaged app with a real preload bridge; this jsdom host and every test run bridgeless and take the `{}` arm. -- @preserve */
  return hasApi() ? { onJobDone } : {};
}

/** Map asset name -> AssetInfo for O(1) size/installed lookup. */
export function indexAssets(assets: AssetInfo[]): Record<string, AssetInfo> {
  const out: Record<string, AssetInfo> = {};
  for (const a of assets) out[a.name] = a;
  return out;
}

/** Whether a model card's weights are installed (zero-download floors -> true). */
export function isInstalled(
  component: ComponentStatus,
  byAsset: Record<string, AssetInfo>,
): boolean {
  const asset = componentAsset(component.name);
  if (!asset) return true; // CPU floor — nothing to download.
  return Boolean(byAsset[asset]?.installed);
}

/** The download size MB for a model card (null = zero-download floor / unknown). */
export function sizeForComponent(
  component: ComponentStatus,
  byAsset: Record<string, AssetInfo>,
): number | null {
  const asset = componentAsset(component.name);
  if (!asset) return null;
  const info = byAsset[asset];
  return info && Number.isFinite(info.sizeMB) ? info.sizeMB : null;
}

/**
 * WU-B3 — whether `system.recommend` could not detect the device (G-B1). The
 * sidecar's typed fallback returns an EMPTY `routing.perFunction`, so an empty
 * map is the falsifiable "unavailable" signal the card renders as an announced
 * "could not detect" message (never a blank card).
 */
export function recommendationUnavailable(rec: Recommendation): boolean {
  return Object.keys(rec.routing.perFunction).length === 0;
}

/**
 * WU-B3 — whether the user's CURRENT settings already match the recommendation,
 * so Apply is a no-op. True iff the active preset equals the recommended preset,
 * the recommended ASR engine is already selected (or none is proposed), the
 * recommendation proposes no downloads, AND every per-function route it proposes
 * already matches the current routing. The routing check is load-bearing: the
 * recommender folds detected-local-server deltas (e.g. `select → local-ollama`,
 * the headline "no cloud egress" value) INDEPENDENTLY of the preset, so a
 * preset+ASR match can still hide a pending routing delta — omitting it would
 * declare "already optimal" and make that local-routing recommendation
 * un-appliable from the card. Pure (settings + recommendation in).
 */
export function recommendationAlreadyOptimal(
  rec: Recommendation,
  activePreset: string | undefined,
  asrEngine: string | undefined,
  currentRouting: RoutingBlock | undefined,
): boolean {
  if (rec.preset !== activePreset) return false;
  if (rec.downloads.length > 0) return false;
  const current = currentRouting?.perFunction ?? {};
  for (const [function_, slot] of Object.entries(rec.routing.perFunction)) {
    if (current[function_]?.provider !== slot.provider) return false;
  }
  return rec.asrEngine === null || rec.asrEngine === asrEngine;
}

/**
 * WU-B3 — a short, perceivable outcome summary announced after Apply runs (the
 * polite live region). Pure: derives the human sentence from what was applied so
 * the one-click result is conveyed without re-reading the panel.
 */
export function applyOutcomeText(rec: Recommendation): string {
  const parts = [`preset ${rec.preset}`];
  if (rec.asrEngine) parts.push(`ASR → ${rec.asrEngine}`);
  if (rec.downloads.length > 0) {
    parts.push(`${rec.downloads.length} download${rec.downloads.length === 1 ? '' : 's'} started`);
  }
  return `Applied: ${parts.join(', ')}.`;
}

/**
 * HARDENING (Settings › Models crash-blank guard) — the sidecar is an UNTRUSTED
 * boundary. The panel maps over `report.tiers/components/notes`,
 * `overview.eligibility.models`, `runners.runners` and reads
 * `recommendation.routing.perFunction`. A structurally-broken (NON-null) payload
 * with a required array/object missing would throw during render and, with no
 * top-level error boundary, blank the ENTIRE app. Each `isRenderable*` guard
 * asserts the exact shape the panel accesses so a broken payload is rejected at
 * INGESTION (stored as null → the section hides AND a LOUD error is surfaced),
 * never a silent blank and never a silent degrade. `null`/`undefined` (capability
 * legitimately absent) is NOT malformed — it hides the section quietly, the
 * established progressive-disclosure pattern.
 */
export function isRenderableReport(report: AdvisorReport): boolean {
  return [report.components, report.tiers, report.notes].every((value) => Array.isArray(value));
}

export function isRenderableOverview(overview: ModelsOverview): boolean {
  return Array.isArray(overview.eligibility?.models) && overview.routingPolicy != null;
}

export function isRenderableRunners(plan: LocalModelPlan): boolean {
  return plan.whisper != null && plan.llm != null && Array.isArray(plan.runners);
}

export function isRenderableRecommendation(rec: Recommendation): boolean {
  return (
    rec.routing?.perFunction != null && Array.isArray(rec.downloads) && Array.isArray(rec.rationale)
  );
}

/**
 * Store a sidecar payload ONLY when it has the shape the panel renders. A
 * `null`/`undefined` payload passes through as null (the section hides quietly).
 * A present-but-malformed payload is rejected (returns null) and `onMalformed`
 * fires so the caller can raise a LOUD error — the crash-blank guard's whole
 * point is that a broken payload degrades to an announced empty, not a blank app.
 */
export function ingestRenderable<T>(
  raw: T | null | undefined,
  isRenderable: (value: T) => boolean,
  onMalformed: () => void,
): T | null {
  if (raw == null) return null;
  if (isRenderable(raw)) return raw;
  onMalformed();
  return null;
}

/** The user-facing (LOUD) message when the sidecar returns malformed panel data. */
export function malformedDataMessage(parts: readonly string[]): string {
  return `Analysis returned unexpected data (${parts.join(', ')}). Those panels are unavailable — re-analyze or update the app.`;
}

export interface ModelsSystemPanelProps {
  /** Inject the typed client for tests; defaults to the real lib/rpc client. */
  rpcClient?: typeof client;
  /**
   * WU-PROVIDERS: navigate to the Providers & Keys section. A readiness fix
   * action of kind `openProviders` (add a key) or `setConsent` (grant consent)
   * routes here instead of dead-ending on this panel. Optional: when absent the
   * key/consent actions no-op (the host did not wire navigation).
   */
  onOpenProviders?: () => void;
  /**
   * F34/F36: the `job.done` bridge the asset-download wait subscribes to.
   * Injected because `assets.ensure` is a LONG job — its rpc promise resolves at
   * ENQUEUE with only `{jobId}`, so the terminal result is reachable only through
   * this channel (`features/_api.ts:167-178`). Defaults to
   * {@link defaultJobBridge}; tests inject a stub because they install no
   * `window.api`.
   */
  jobBridge?: JobDoneCapable;
}

interface SettingsShape {
  phase8Tier?: number;
  asrEngine?: string;
  diarizeBackend?: string;
  commercial?: boolean;
  modelsOnboardingSeen?: boolean;
  activePreset?: string;
  routing?: RoutingBlock;
  firstRunChoiceMade?: boolean;
  // M3 POINT: non-default local-runner base URLs the detector probes.
  ollamaBaseUrl?: string;
  lmStudioBaseUrl?: string;
  // M5 RO alignment opt-in: the word-timing CTC model id ('' = the packaged
  // Apache-2.0 default; WU-T0/B1 flipped that away from the CC-BY-NC MMS model).
  ctcModelId?: string;
  // WU-T0/B1: unlocks the CC-BY-NC-4.0 MMS aligner. The sidecar refuses that
  // model unless this is truthy, so the picker must read the SAME key.
  allowNonCommercialAligner?: boolean;
}

export function ModelsSystemPanel({
  rpcClient,
  onOpenProviders,
  jobBridge,
}: ModelsSystemPanelProps): React.ReactElement {
  /* v8 ignore next -- the `?? client` default only runs in the real app; every test injects rpcClient. -- @preserve */
  const api = useMemo(() => rpcClient ?? client, [rpcClient]);
  const jobs = useMemo<JobDoneCapable>(() => jobBridge ?? defaultJobBridge(), [jobBridge]);

  const [hardware, setHardware] = useState<HardwareInfo | null>(null);
  const [report, setReport] = useState<AdvisorReport | null>(null);
  const [assets, setAssets] = useState<AssetInfo[]>([]);
  const [engines, setEngines] = useState<AsrEngine[]>([]);
  const [settings, setSettings] = useState<SettingsShape>({});
  const [analyzed, setAnalyzed] = useState<boolean>(false);
  const [busy, setBusy] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  // F34: a SET, not one name. The busy flag now spans the WHOLE download job
  // (minutes, not the enqueue instant), and a panel-global lock would make every
  // OTHER model's Download button look enabled while doing nothing — a dead click.
  const [downloading, setDownloading] = useState<ReadonlySet<string>>(() => new Set<string>());
  const [showTour, setShowTour] = useState<boolean>(false);
  const [usage, setUsage] = useState<UsageRow[]>([]);
  // WU-models/device: local-runner plan (device-ranked whisper+LLM + runner advice)
  // and per-key OpenRouter COST rows (the cost axis alongside the calls/tokens bars).
  const [runners, setRunners] = useState<LocalModelPlan | null>(null);
  // M2: the composed Models & System overview drives the "using X because Y"
  // reason strip + device card (real quant + VRAM estimate, null-RAM graceful).
  const [overview, setOverview] = useState<ModelsOverview | null>(null);
  const [openrouterUsage, setOpenrouterUsage] = useState<OpenRouterUsageRow[]>([]);
  // WU-D4: honest per-provider note on whether a provider-side usage API exists
  // (OpenRouter yes; OpenAI/Anthropic need an org admin key; others none). Shown so
  // a provider without a usage API says so instead of implying a fabricated 0.
  const [usageAvailability, setUsageAvailability] = useState<UsageAvailabilityRow[]>([]);
  const [catalog, setCatalog] = useState<CatalogResponse | null>(null);
  const [presetBusy, setPresetBusy] = useState<boolean>(false);
  // WU-B3 device-aware recommendation card + one-click Apply.
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);
  const [applying, setApplying] = useState<boolean>(false);
  const [applyOutcome, setApplyOutcome] = useState<string>('');

  const byAsset = useMemo(() => indexAssets(assets), [assets]);

  // F34: tear a pending job-wait down on unmount. Without it a Settings sub-tab
  // switch mid-download leaves the `job.done` subscription and its timer alive to
  // the DEFAULT_JOB_TIMEOUT_MS ceiling (~35 min).
  //
  // A live controller is always present and is REPLACED per job (`runAssetJob`),
  // exactly the `views/Export.tsx:75,108` pattern. Two properties are load-bearing:
  //
  //  1. The cleanup must read `abortRef.current` AT CLEANUP TIME, not capture it at
  //     setup time. `main.tsx` wraps the app in `React.StrictMode`, so in dev the
  //     effect runs setup -> cleanup -> setup; a captured `ctrl` meant the cleanup
  //     aborted the ONE controller the panel would ever use. `waitForJobDone`
  //     short-circuits on `signal?.aborted` (`_api.ts:266-269`) and
  //     `surfaceJobError` swallows `JobAbortedError`, so every Download and every
  //     readiness fix action enqueued its multi-GB job and then silently no-op'd,
  //     with the error path muted — in the exact environment where a human would
  //     hand-verify this. Measured: effect setups=2, cleanups=1,
  //     `signal.aborted` at click time = true.
  //  2. Because the controller is replaced per job, the StrictMode cleanup aborts
  //     only the initial controller, which nothing is ever awaiting.
  const abortRef = useRef<AbortController>(new AbortController());
  useEffect(() => () => abortRef.current.abort(), []);

  // Load persisted settings up-front (cheap) so the tier/ASR/commercial controls
  // reflect saved choices even before the opt-in analysis runs.
  useEffect(() => {
    let alive = true;
    api.settings
      .get()
      .then((s) => {
        if (alive) setSettings((s ?? {}) as SettingsShape);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [api]);

  // Progressive disclosure: load the CHEAP, probe-INDEPENDENT data up-front so
  // the AI-presets, ASR/diarization, and provider-usage controls work BEFORE the
  // user opts into the (heavier, privacy-sensitive) hardware analysis. None of
  // these reads touches the hardware probe, so the opt-in-probe contract holds.
  // A failed read degrades that one control quietly (never the panel, never the
  // alert region) — the opt-in prompt still renders.
  useEffect(() => {
    let alive = true;
    Promise.all([
      api.providers.catalog().catch(() => null),
      api.asr.engines().catch(() => null),
      api.providers.usage().catch(() => null),
      api.providers.openrouterUsage().catch(() => null),
      api.providers.usageAvailability().catch(() => null),
    ])
      .then(([catalogRes, engineRes, usageRes, orRes, availRes]) => {
        if (alive) {
          if (catalogRes) setCatalog(catalogRes);
          if (engineRes) setEngines(Array.isArray(engineRes.engines) ? engineRes.engines : []);
          if (usageRes) setUsage(Array.isArray(usageRes.usage) ? usageRes.usage : []);
          if (orRes) setOpenrouterUsage(Array.isArray(orRes.usage) ? orRes.usage : []);
          if (availRes)
            setUsageAvailability(Array.isArray(availRes.availability) ? availRes.availability : []);
        }
      })
      /* v8 ignore start -- every inner read already .catch()es to null, so the outer Promise.all never rejects; this is a belt-and-braces guard. (Block form: the `next N` hint does not survive esbuild's transform for arrow-in-call-chain positions.) -- @preserve */
      .catch(() => undefined);
    /* v8 ignore stop -- @preserve */
    return () => {
      alive = false;
    };
  }, [api]);

  // Opt-in analysis: probe hardware + advisor + asset/engine state in parallel.
  const analyze = useCallback(async (): Promise<void> => {
    /* v8 ignore next -- re-entrancy guard: the Analyze button is disabled while busy, so this never trips in tests. -- @preserve */
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      const commercial = Boolean(settings.commercial);
      const [hw, rep, assetRes, engineRes, usageRes, catalogRes, recRes, runnersRes, overviewRes] =
        await Promise.all([
          api.system.probe(),
          api.system.advisor({ commercial }),
          api.assets.list(),
          api.asr.engines(),
          api.providers.usage(),
          api.providers.catalog(),
          api.system.recommend({ commercial }),
          api.models.runners(),
          // M2: the unified compose carries the metadata-driven eligibility
          // (real quant + VRAM est) the reason strip names.
          api.models.overview({ commercial }),
        ]);
      // HARDENING: reject any present-but-malformed payload at ingestion so a
      // sidecar-data-coupled break degrades to an announced empty, never a blank
      // app. Collect the broken payload names to surface ONE loud error below.
      const malformed: string[] = [];
      const flag = (what: string) => (): void => void malformed.push(what);
      setHardware(hw ?? null);
      setReport(ingestRenderable(rep, isRenderableReport, flag('system report')));
      setAssets(Array.isArray(assetRes?.assets) ? assetRes.assets : []);
      setEngines(Array.isArray(engineRes?.engines) ? engineRes.engines : []);
      setUsage(Array.isArray(usageRes?.usage) ? usageRes.usage : []);
      setCatalog(catalogRes ?? null);
      setRecommendation(
        ingestRenderable(
          recRes?.recommendation,
          isRenderableRecommendation,
          flag('setup recommendation'),
        ),
      );
      setRunners(ingestRenderable(runnersRes, isRenderableRunners, flag('local model plan')));
      setOverview(ingestRenderable(overviewRes, isRenderableOverview, flag('models overview')));
      setApplyOutcome('');
      if (malformed.length > 0) setError(malformedDataMessage(malformed));
      setAnalyzed(true);
      // First-run tour: show once if the user hasn't seen it.
      if (!settings.modelsOnboardingSeen) setShowTour(true);
    } catch (err) {
      setError(errText(err));
    } finally {
      setBusy(false);
    }
  }, [api, busy, settings.commercial, settings.modelsOnboardingSeen]);

  // Re-probe only the hardware (cheap), e.g. after plugging in a GPU.
  const reprobe = useCallback(async (): Promise<void> => {
    try {
      const hw = await api.system.probe();
      setHardware(hw ?? null);
    } catch (err) {
      setError(errText(err));
    }
  }, [api]);

  // Refresh per-key usage on demand (cached on the sidecar; no poll burst).
  const refreshUsage = useCallback(async (): Promise<void> => {
    try {
      const res = await api.providers.usage();
      setUsage(Array.isArray(res?.usage) ? res.usage : []);
    } catch (err) {
      setError(errText(err));
    }
  }, [api]);

  // Persist a settings patch and reflect it locally (best-effort).
  const patchSettings = useCallback(
    async (patch: SettingsShape): Promise<void> => {
      setSettings((prev) => ({ ...prev, ...patch }));
      try {
        await api.settings.set(patch as Record<string, unknown>);
      } catch (err) {
        setError(errText(err));
      }
    },
    [api],
  );

  const selectTier = useCallback(
    (tier: number) => void patchSettings({ phase8Tier: tier }),
    [patchSettings],
  );

  // M5: persist a PARTIAL routing-policy patch via the fail-closed
  // setRoutingPolicy write (NOT settings.set — the sidecar sanitises/clamps), then
  // reflect the policy the sidecar actually persisted back into the overview so the
  // override table + reason strip stay in sync. Best-effort: a failed write keeps
  // the prior overview policy.
  //
  // F35: the parameter is a PATCH, not a whole policy — the table sends only the
  // `overrides` half it owns and the sidecar merges per half, so a row edit can no
  // longer clobber the header's `global`. Folding the RETURNED policy back in also
  // refreshes the panel's snapshot of `global` from disk — but only on the panel's
  // OWN write, so a header click alone still leaves the table's intro text stale.
  const applyRoutingPolicy = useCallback(
    async (policy: Partial<RoutingPolicy>): Promise<void> => {
      try {
        const { routingPolicy } = await api.models.setRoutingPolicy(policy);
        setOverview((prev) => mergeOverviewRoutingPolicy(prev, routingPolicy));
      } catch (err) {
        setError(errText(err));
      }
    },
    [api],
  );

  // WU-presets: apply a smart preset -> server resolves routing.perFunction.
  const applyAiPreset = useCallback(
    async (name: string): Promise<void> => {
      setPresetBusy(true);
      setError('');
      try {
        const res = await api.providers.applyPreset(name);
        setSettings((prev) => ({ ...prev, activePreset: res.activePreset, routing: res.routing }));
      } catch (err) {
        setError(errText(err));
      } finally {
        setPresetBusy(false);
      }
    },
    [api],
  );

  // WU-presets: override one function's routed provider.
  const setFunctionModel = useCallback(
    async (function_: string, provider: string): Promise<void> => {
      setPresetBusy(true);
      setError('');
      try {
        const res = await api.providers.setFunctionModel(function_, provider);
        setSettings((prev) => ({ ...prev, activePreset: res.activePreset, routing: res.routing }));
      } catch (err) {
        setError(errText(err));
      } finally {
        setPresetBusy(false);
      }
    },
    [api],
  );

  // WU-presets P1 #6: the first-run local-vs-cloud choice flips routing + sets
  // firstRunChoiceMade so the chooser never shows again.
  const chooseFirstRun = useCallback(
    async (choice: 'privacy' | 'bestFreeCloud'): Promise<void> => {
      setPresetBusy(true);
      setError('');
      try {
        const res = await api.providers.firstRun(choice);
        setSettings((prev) => ({
          ...prev,
          firstRunChoiceMade: res.firstRunChoiceMade,
          activePreset: res.activePreset ?? prev.activePreset,
          routing: res.routing ?? prev.routing,
        }));
      } catch (err) {
        setError(errText(err));
      } finally {
        setPresetBusy(false);
      }
    },
    [api],
  );

  // WU-B3 one-click Apply: reuses the EXISTING mutation RPCs only (no new
  // mutation path). Order: applyPreset (base routing) -> per-function deltas the
  // recommender folded over the base (detected-local capture) -> persist the ASR
  // engine -> queue the proposed downloads. Announces the outcome politely.
  const applyRecommendation = useCallback(
    async (rec: Recommendation): Promise<void> => {
      setApplying(true);
      setApplyOutcome('');
      setError('');
      try {
        const base = await api.providers.applyPreset(rec.preset);
        let routing = base.routing;
        let activePreset = base.activePreset;
        for (const [function_, slot] of Object.entries(rec.routing.perFunction)) {
          const current = base.routing.perFunction[function_];
          if (current?.provider !== slot.provider) {
            const res = await api.providers.setFunctionModel(function_, slot.provider);
            routing = res.routing;
            activePreset = res.activePreset;
          }
        }
        if (rec.asrEngine) await api.settings.set({ asrEngine: rec.asrEngine });
        if (rec.downloads.length > 0) {
          await api.assets.ensure(rec.downloads.map((d) => d.assetName));
        }
        setSettings((prev) => ({
          ...prev,
          activePreset,
          routing,
          ...(rec.asrEngine ? { asrEngine: rec.asrEngine } : {}),
        }));
        setApplyOutcome(applyOutcomeText(rec));
      } catch (err) {
        setError(errText(err));
      } finally {
        setApplying(false);
      }
    },
    [api],
  );

  const applyPreset = useCallback(() => {
    /* v8 ignore next -- the Apply-preset button only renders inside the `analyzed && report` block, so report is always set here. -- @preserve */
    if (!report) return;
    void patchSettings({ phase8Tier: presetTier(report.recommendedPreset) });
  }, [report, patchSettings]);

  const toggleCommercial = useCallback(() => {
    void patchSettings({ commercial: !settings.commercial });
  }, [patchSettings, settings.commercial]);

  const finishTour = useCallback(() => {
    setShowTour(false);
    void patchSettings({ modelsOnboardingSeen: true });
  }, [patchSettings]);

  // F34: announce a job failure — EXCEPT a clean abort. `waitForJobDone` rejects
  // with JobAbortedError on unmount/cancel, which is an idle reset, not a fault
  // to show the user (precedent: Export.tsx:130-133).
  const surfaceJobError = useCallback((err: unknown): void => {
    if (!(err instanceof JobAbortedError)) setError(errText(err));
  }, []);

  // F34/F36 — the ONE shared "install assets and wait for the job to ACTUALLY
  // finish" path, used by both the per-model Download and the readiness roll-up.
  //
  // `assets.ensure` is a LONG job: its rpc promise resolves at ENQUEUE with only
  // `{jobId}` (`assets/rpc.py:91-92`), so the previous code reported completion it
  // had never observed — the button reverted while bytes were still moving, the
  // post-enqueue `assets.list` could not yet see `installed` (the download only
  // renames `.part` -> dest at the very end, `manager.py:863-875`), and a FAILED
  // download was invisible because the error only ever arrives on `job.done`.
  const runAssetJob = useCallback(
    async (assetNames: string[]): Promise<void> => {
      // Fresh controller per job (see the `abortRef` note above): the mount-time
      // one may already be aborted by StrictMode's double-invoke, and reusing an
      // aborted signal makes `waitForJobDone` return null immediately.
      const controller = new AbortController();
      abortRef.current = controller;
      const { jobId } = await api.assets.ensure(assetNames);
      const done = await waitForJobDone<EnsureDone>(
        jobs,
        jobId,
        extractEnsureDone,
        DEFAULT_JOB_TIMEOUT_MS,
        controller.signal,
      );
      // A SUCCESS payload can still carry per-item failures (manager.py:742-749
      // raises only when NOTHING installed), so a partial failure must be shown.
      const failed = done === null ? [] : done.failed;
      if (failed.length > 0) setError(ensureFailureText(failed));
      // The job payload already carries the refreshed rows; re-list only when it
      // did not (a bridgeless host resolved null, or a partial payload).
      const rows = done?.assets ?? (await api.assets.list()).assets;
      setAssets(Array.isArray(rows) ? rows : []);
      // Re-run the advisor so installed-state flips the verdicts/recommendation.
      const rep = await api.system.advisor({ commercial: Boolean(settings.commercial) });
      setReport(
        ingestRenderable(rep, isRenderableReport, () =>
          setError(malformedDataMessage(['system report'])),
        ),
      );
    },
    [api, jobs, settings.commercial],
  );

  // Download a single model: hold THIS card busy for the whole job, then refresh.
  const download = useCallback(
    async (componentName: string): Promise<void> => {
      const asset = componentAsset(componentName);
      /* v8 ignore next -- defensive guard: floor components (no asset) render an "Installed", disabled button, and this card's Download button is disabled while it downloads, so neither arm trips in tests. -- @preserve */
      if (!asset || downloading.has(componentName)) return;
      setDownloading((prev) => new Set(prev).add(componentName));
      setError('');
      try {
        await runAssetJob([asset]);
      } catch (err) {
        surfaceJobError(err);
      } finally {
        setDownloading((prev) => {
          const next = new Set(prev);
          next.delete(componentName);
          return next;
        });
      }
    },
    [downloading, runAssetJob, surfaceJobError],
  );

  // WU-14 / WU-PROVIDERS: the readiness roll-up surfaces a fix action per
  // not-ready capability.
  //   * `assets.ensure` — install the named weights here, then re-list assets +
  //     re-run the advisor (same effect as a per-model Download).
  //   * `openProviders` (add a key) / `setConsent` (grant consent) — navigate to
  //     the Providers & Keys section via `onOpenProviders` (fixes the previous
  //     early-return dead-end where these actions did nothing).
  const handleReadinessAction = useCallback(
    async (action: ReadinessAction): Promise<void> => {
      if (action.kind === 'openProviders' || action.kind === 'setConsent') {
        onOpenProviders?.();
        return;
      }
      if (!action.assets || action.assets.length === 0) return;
      setError('');
      try {
        // F36: the SAME job-wait as the per-card Download — a refresh without it
        // would re-read pre-download state, so the roll-up's badge would still be
        // wrong. Returning the promise lets the roll-up hold the button busy and
        // re-read `readiness.summary` only once the job has truly finished.
        await runAssetJob(action.assets);
      } catch (err) {
        surfaceJobError(err);
      }
    },
    [runAssetJob, surfaceJobError, onOpenProviders],
  );

  const currentTier = settings.phase8Tier ?? 1;
  const recommendedTier = report ? presetTier(report.recommendedPreset) : 0;
  // WU-B3 derived card state (pure helpers; recomputed on settings/rec change).
  const recUnavailable = recommendation ? recommendationUnavailable(recommendation) : false;
  const recOptimal =
    recommendation !== null &&
    !recUnavailable &&
    recommendationAlreadyOptimal(
      recommendation,
      settings.activePreset,
      settings.asrEngine,
      settings.routing,
    );
  const applyDisabled = applying || recOptimal;
  const applyName = recOptimal
    ? 'Your settings already match the recommendation'
    : 'Apply recommended settings';

  // H3: the ONE predicate the empty-state prompt and the toolbar analyze button
  // both read, so they can never render together again. Previously each site
  // spelled `!analyzed && !busy` for itself, which is what let the duplicate exist.
  const showPrompt = !analyzed && !busy;

  return (
    <section className="feature-panel models-system-panel" aria-label="Models and System">
      <h2>Models &amp; System</h2>
      <p className="assets-intro">
        See what your machine can run, pick a quality tier for moment-finding, and download only the
        models you need. Analysis is opt-in and runs locally — nothing is uploaded.
      </p>

      <ReadinessRollup
        rpcClient={api}
        title="What works right now"
        onAction={handleReadinessAction}
      />

      <div className="actions">
        {/* H3 (docs/plans/v1.5/uiux-qol-audit-2026-08.md §5) — this button and the
            empty-state CTA below both read "Analyze my system" and both call
            `analyze()`, so an un-analyzed panel rendered the SAME control twice
            (measured live at 552,161 and 576,326). The audit records C1 and H3 as
            masking each other: C1's landing-scrolled bug kept this copy off-screen,
            so fixing C1 is what made the pair visible together.

            The CTA wins the un-analyzed state because it is the one carrying the
            explanation; suppressing IT instead would leave the empty state a
            paragraph with no way forward. This button owns the other two states,
            where it is the only affordance — hence `Analyzing…` / `Re-analyze` and
            no third label: `!showPrompt` means `analyzed || busy`, so a bare
            "Analyze my system" here is unreachable, not merely unused. */}
        {!showPrompt && (
          <button
            type="button"
            data-action="analyze"
            onClick={() => void analyze()}
            disabled={busy}
            title={busy ? 'Analysis is already running…' : undefined}
          >
            {busy ? 'Analyzing…' : 'Re-analyze'}
          </button>
        )}
        {analyzed && (
          <button
            type="button"
            data-action="tour"
            className="secondary"
            onClick={() => setShowTour(true)}
          >
            Show tour again
          </button>
        )}
        <label className="commercial-toggle" title="Hide models with non-commercial licenses">
          <input
            type="checkbox"
            data-action="commercial"
            checked={Boolean(settings.commercial)}
            onChange={toggleCommercial}
          />
          <span>Commercial use</span>
        </label>
      </div>

      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}

      {showPrompt && (
        <div className="empty-state" data-section="prompt">
          <p className="empty-state__title">See what your machine can run</p>
          <p className="empty-state__body">
            Detect your hardware to see per-model and per-tier “will it run” verdicts and a
            recommended setup. The presets, speech engine, and provider-usage controls below already
            work — analysis is opt-in and runs locally.
          </p>
          <button
            type="button"
            className="empty-state__cta"
            data-action="analyze-cta"
            onClick={() => void analyze()}
          >
            Analyze my system
          </button>
        </div>
      )}

      {/* WU-B3: loading live region while system.recommend (inside analyze) runs. */}
      {busy && (
        <p className="status" data-section="recommend-loading" role="status" aria-live="polite">
          Analysing your machine…
        </p>
      )}

      {/* M2: the novice "using X because Y" headline — names the real quant +
          VRAM estimate when a detected Ollama runner exposes metadata, else the
          advisor's verbatim device-ranked reason; RAM reads "unknown" gracefully. */}
      {analyzed && overview && <ReasonStrip overview={overview} />}

      {/* M3 Advanced disclosure: model SORT (VRAM-fit/size/name) over the
          metadata eligibility + manual runner POINT (base URL/port) — the
          detector honours ollamaBaseUrl/lmStudioBaseUrl on the next analyse. */}
      {analyzed && overview && (
        <AdvancedModels
          models={overview.eligibility.models}
          ollamaBaseUrl={settings.ollamaBaseUrl ?? ''}
          lmStudioBaseUrl={settings.lmStudioBaseUrl ?? ''}
          onApplyRunnerUrls={(patch) => void patchSettings(patch)}
        />
      )}

      {/* M5: per-function routing override table (Settings/Advanced) — sets
          RoutingPolicy.overrides[fn] over the M3 global toggle; degrade-to-local
          is surfaced per-job by the sidecar concrete resolver. */}
      {analyzed && overview && (
        <RoutingOverrideTable
          policy={overview.routingPolicy}
          onApply={(policy) => void applyRoutingPolicy(policy)}
        />
      )}

      {/* M5 + WU-T0/B1: the alignment-model picker over settings.ctcModelId,
          plus the allowNonCommercialAligner opt-in that unlocks (never selects)
          the CC-BY-NC MMS model. Both keys are read by the sidecar's single
          `ctc_align._resolve_model_id`.
          This comment used to claim "so the UI cannot drift from the gate" — it
          could, and it did: sharing an input says nothing about agreeing on the
          output, and the drift shipped green because each suite only checked its
          own side. The actual guard is the cross-file
          test_the_settings_dropdown_label_matches_the_model_that_will_actually_run
          in sidecar/tests/test_ctc_align.py. */}
      {analyzed && (
        <AlignModelSelect
          value={settings.ctcModelId ?? ''}
          onChange={(ctcModelId) => void patchSettings({ ctcModelId })}
          allowNonCommercial={settings.allowNonCommercialAligner ?? false}
          onAllowNonCommercialChange={(allowNonCommercialAligner) =>
            void patchSettings({ allowNonCommercialAligner })
          }
        />
      )}

      {analyzed && hardware && (
        <div className="hardware-header" data-section="hardware">
          <h3>Your hardware</h3>
          <div className="hardware-header__bars">
            <ResourceBar
              label="VRAM budget"
              used={report?.vramBudgetMb ?? hardware.vramMb}
              total={hardware.vramMb}
              hint="Each heavy model must fit under this on its own."
            />
            <ResourceBar label="System RAM" used={hardware.ramMb} total={hardware.ramMb} />
          </div>
          <div className="hardware-header__chips">
            <span className="hw-chip" data-chip="cpu">
              {hardware.cpuCount ? `${hardware.cpuCount} CPU cores` : 'CPU cores: unknown'}
            </span>
            <span className={`hw-chip${hardware.gpuPresent ? ' is-on' : ''}`} data-chip="gpu">
              {hardware.gpuPresent ? 'GPU detected' : 'No GPU detected'}
            </span>
            <button
              type="button"
              data-action="reprobe"
              className="secondary"
              onClick={() => void reprobe()}
            >
              Re-probe
            </button>
          </div>
          {/* WU-models/device: the device + per-job ETA status strip (free disk /
              RAM / VRAM / GPU). ETA is idle here (Settings runs no job). */}
          <DeviceStatusStrip hardware={hardware} />
        </div>
      )}

      {/* WU-models/device: device-ranked model recommendation ("X because RAM/VRAM
          Y") + local-runner (Ollama / LM Studio) detect / pull / install advice. */}
      {analyzed && runners && (
        <>
          <DeviceModelReco whisper={runners.whisper} llm={runners.llm} />
          <LocalRunners runners={runners.runners} />
        </>
      )}

      {analyzed && report && (
        <>
          <div
            className="preset-banner"
            data-section="preset"
            data-preset={report.recommendedPreset}
          >
            <div className="preset-banner__text">
              <span className="preset-banner__eyebrow">Recommended for your machine</span>
              <span className="preset-banner__name">{presetLabel(report.recommendedPreset)}</span>
            </div>
            <button type="button" data-action="apply-preset" onClick={applyPreset}>
              Apply preset
            </button>
          </div>

          {/* WU-B3: device-aware recommendation card + one-click Apply. */}
          {recommendation && (
            <section
              className="recommend-card"
              data-section="recommend"
              aria-labelledby="recommend-card-heading"
            >
              <h3 id="recommend-card-heading">Recommended setup for your machine</h3>
              {recUnavailable ? (
                <p
                  className="recommend-card__unavailable"
                  data-section="recommend-unavailable"
                  role="status"
                  aria-live="polite"
                >
                  Could not detect your hardware — pick a preset manually using the controls below.
                </p>
              ) : (
                <>
                  <dl className="recommend-card__plan" data-section="recommend-plan">
                    <div className="recommend-card__row">
                      <dt>Preset</dt>
                      <dd data-field="preset">{presetLabel(recommendation.preset)}</dd>
                    </div>
                    {recommendation.asrEngine && (
                      <div className="recommend-card__row">
                        <dt>Speech engine</dt>
                        <dd data-field="asr">{recommendation.asrEngine}</dd>
                      </div>
                    )}
                    {recommendation.downloads.length > 0 && (
                      <div className="recommend-card__row">
                        <dt>Downloads</dt>
                        <dd data-field="downloads">
                          {recommendation.downloads.map((d) => d.label).join(', ')}
                        </dd>
                      </div>
                    )}
                  </dl>

                  <h4 className="recommend-card__why-heading">Why</h4>
                  <ul className="recommend-card__rationale" data-section="recommend-rationale">
                    {recommendation.rationale.map((line) => (
                      <li key={line} className="recommend-card__rationale-item">
                        {line}
                      </li>
                    ))}
                  </ul>

                  <button
                    type="button"
                    className="recommend-card__apply"
                    data-action="apply-recommendation"
                    aria-label={applyName}
                    // DISABLED clarity: a hover tooltip surfaces the WHY (the same
                    // reason the SR-only aria-label carries) so a sighted user
                    // learns why a greyed Apply is inert.
                    title={applyName}
                    aria-busy={applying}
                    disabled={applyDisabled}
                    onClick={() => void applyRecommendation(recommendation)}
                  >
                    {applying ? 'Applying…' : 'Apply recommended settings'}
                  </button>
                  {recOptimal && (
                    <p className="recommend-card__optimal" data-section="recommend-optimal">
                      Your settings already match the recommendation.
                    </p>
                  )}
                  <p
                    className="recommend-card__outcome"
                    data-section="recommend-outcome"
                    role="status"
                    aria-live="polite"
                  >
                    {applyOutcome}
                  </p>
                </>
              )}
            </section>
          )}

          <h3>Quality tier</h3>
          <div className="tier-grid" data-section="tiers">
            {report.tiers.map((tier) => (
              <TierCard
                key={tier.tier}
                tier={tier}
                selected={currentTier === tier.tier}
                recommended={recommendedTier === tier.tier}
                onSelect={selectTier}
              />
            ))}
          </div>

          <h3>Models</h3>
          <ul className="model-grid" data-section="models">
            {report.components.map((component) => (
              <ModelCard
                key={component.name}
                component={component}
                qualityFraction={qualityFraction(component.name, report)}
                vramBudgetMb={report.vramBudgetMb}
                installed={isInstalled(component, byAsset)}
                sizeMb={sizeForComponent(component, byAsset)}
                downloading={downloading.has(component.name)}
                onDownload={download}
              />
            ))}
          </ul>

          {report.notes.length > 0 && (
            <div className="notes-strip" data-section="notes">
              <h3>Notes</h3>
              <ul className="notes-list">
                {report.notes.map((note) => (
                  <li key={note} className="notes-item">
                    {note}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}

      {/* Progressive disclosure: these are probe-INDEPENDENT controls (their data
          loads on mount), so they render whether or not the user has opted into
          the hardware analysis — the panel is never a blank "analyze first" wall. */}
      <h3>Speech &amp; diarization</h3>
      <div className="speech-section" data-section="speech">
        <div className="field">
          <label htmlFor="asr-engine">ASR engine</label>
          <select
            id="asr-engine"
            data-action="asr-engine"
            value={settings.asrEngine ?? 'whisper'}
            onChange={(e) => void patchSettings({ asrEngine: e.target.value })}
          >
            {(engines.length > 0
              ? engines
              : [{ id: 'whisper', label: 'Whisper', installed: true }]
            ).map((engine) => (
              <option key={engine.id} value={engine.id}>
                {engine.label}
                {engine.installed ? '' : ' (not installed)'}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="diarize-backend">Diarization backend</label>
          <select
            id="diarize-backend"
            data-action="diarize-backend"
            value={settings.diarizeBackend ?? 'speechbrain'}
            onChange={(e) => void patchSettings({ diarizeBackend: e.target.value })}
          >
            <option value="speechbrain">SpeechBrain (token-free, default)</option>
            <option value="pyannote">pyannote 3.1 (needs HF token)</option>
          </select>
          {(settings.diarizeBackend ?? 'speechbrain') === 'pyannote' && (
            <p className="field-hint" data-hint="pyannote">
              pyannote needs an HF token (HF_TOKEN) and both gated repos accepted.
            </p>
          )}
        </div>
      </div>

      <div className="usage-section" data-section="usage">
        <div className="usage-section__head">
          <h3>Provider usage</h3>
          <button
            type="button"
            data-action="refresh-usage"
            className="secondary"
            onClick={() => void refreshUsage()}
          >
            Refresh usage
          </button>
        </div>
        <p className="usage-section__intro">
          Live per-key quota from your loaded providers — request- and token-limited keys are shown
          separately and never combined. Updated from response headers, not a poller.
        </p>
        <UsageBars rows={usage} />
        {/* WU-models/device: the COST axis (OpenRouter cumulative credit spend),
            alongside the calls/tokens bars above. Keys are redacted last-4 only. */}
        <div className="usage-section__cost" data-section="openrouter-usage">
          <h4 className="usage-section__cost-head">OpenRouter spend</h4>
          <OpenRouterUsage rows={openrouterUsage} />
        </div>
        {/* WU-D4: honest per-provider note on provider-side usage APIs — a provider
            without one (OpenAI/Anthropic without an org admin key, or others) says
            so plainly instead of implying a fabricated number. */}
        <ProviderUsageAvailability rows={usageAvailability} />
      </div>

      {catalog && (
        <div className="presets-section" data-section="presets-section">
          <PresetPicker
            catalog={catalog}
            routing={settings.routing ?? { perFunction: {} }}
            activePreset={settings.activePreset ?? ''}
            onApplyPreset={(name) => void applyAiPreset(name)}
            onSetFunction={(fn, provider) => void setFunctionModel(fn, provider)}
            busy={presetBusy}
          />
        </div>
      )}

      {!settings.firstRunChoiceMade && (
        <FirstRunChooser onChoose={(choice) => void chooseFirstRun(choice)} busy={presetBusy} />
      )}

      {showTour && <ModelsOnboarding onDone={finishTour} />}
    </section>
  );
}

export default ModelsSystemPanel;
