// Diarize feature panel (system-advanced group, feature 4).
//
// Token-free speaker diarization: SpeechBrain VAD -> ECAPA -> greedy cosine
// clustering -> SPEAKER_NN labels on the transcript. Drives:
//   diarize.start({videoId, threshold?}) -> {jobId} -> job.done {transcript}
//
// The transcript must already exist (run Transcribe first); the result is the
// transcript with a `speaker` on each segment + a `speakers` roster, which this
// panel surfaces. The gated SpeechBrain models are on-demand assets (Assets
// tab); offline mode refuses the run when they are not yet installed. Consumes
// the FROZEN window.api bridge via the shared `./_api` helpers.
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import './panels.css';
import { getApi, pickField, waitForJobDone, type MediaStudioApi, type Segment } from './_api';

// The diarized transcript adds a per-segment `speaker` label + a `speakers`
// roster onto the §3 transcript shape. `Segment` already carries words/timings;
// `speaker` is the diarization addition.
export type DiarizedSegment = Segment & { speaker?: string };
export interface DiarizedTranscript {
  language: string;
  durationSec: number;
  segments: DiarizedSegment[];
  speakers?: string[];
}
export interface DiarizeDoneResult {
  transcript: DiarizedTranscript;
}

// --- pure helpers (exported for tests) -------------------------------------
/** The roster from a done transcript (empty when absent). */
export function extractSpeakers(result: unknown): string[] {
  const transcript = pickField<DiarizedTranscript>(result, 'transcript');
  return Array.isArray(transcript?.speakers) ? transcript!.speakers! : [];
}

export interface DiarizeProps {
  videoId: string;
  /** Injectable bridge for tests; defaults to the preload-exposed api. */
  api?: MediaStudioApi;
}

export function Diarize({ videoId, api }: DiarizeProps): React.ReactElement {
  const bridge = useMemo<MediaStudioApi>(() => api ?? getApi(), [api]);

  const [busy, setBusy] = useState<boolean>(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [pct, setPct] = useState<number>(0);
  const [message, setMessage] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [speakers, setSpeakers] = useState<string[]>([]);
  // Per-speaker rename drafts ({SPEAKER_NN: typed-name}); reset whenever a new
  // roster lands (run/re-run) so stale drafts never leak across diarizations.
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!jobId) return;
    const off = bridge.onProgress((ev) => {
      if (ev.jobId !== jobId) return;
      setPct(ev.pct);
      setMessage(ev.message);
    });
    return off;
  }, [bridge, jobId]);

  const run = useCallback(async (): Promise<void> => {
    // defensive re-entrancy guard: the trigger button is `disabled={busy}`, so a
    // second run cannot be dispatched via UI while one is in flight.
    /* v8 ignore next -- @preserve */
    if (busy) return;
    setBusy(true);
    setError('');
    setSpeakers([]);
    setDrafts({});
    setPct(0);
    setMessage('Starting…');
    try {
      const res = await bridge.rpc<{ jobId: string }>('diarize.start', { videoId });
      const id = res?.jobId ?? null;
      setJobId(id);
      // F1: waitForJobDone REJECTS on an {error} job.done payload (surfaced by
      // the catch below) — no more silent doneErrorMessage swallow. A clean
      // cancel resolves null, leaving an empty roster.
      const result = id ? await waitForJobDone<unknown>(bridge, id, (r) => r ?? null) : null;
      setSpeakers(extractSpeakers(result));
      setPct(100);
      setMessage('Done');
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
      setJobId(null);
    }
  }, [bridge, videoId, busy]);

  const cancel = useCallback(async (): Promise<void> => {
    // defensive: the Cancel button renders only while `busy && jobId`, so cancel
    // is never invoked with a null jobId via UI.
    /* v8 ignore next -- @preserve */
    if (!jobId) return;
    try {
      await bridge.rpc('job.cancel', { jobId });
    } catch {
      // Best-effort.
    }
    setMessage('Cancelling…');
  }, [bridge, jobId]);

  const applyRename = useCallback(async (): Promise<void> => {
    // Build a {SPEAKER_NN: friendly} mapping from drafts that actually changed
    // (trimmed, non-empty, different from the current label). A no-op submit
    // sends nothing to the sidecar.
    const mapping: Record<string, string> = {};
    for (const speaker of speakers) {
      const next = (drafts[speaker] ?? '').trim();
      if (next && next !== speaker) {
        mapping[speaker] = next;
      }
    }
    if (Object.keys(mapping).length === 0) return;
    setError('');
    try {
      const result = await bridge.rpc<unknown>('diarize.rename', { videoId, mapping });
      const roster = extractSpeakers(result);
      if (roster.length > 0) {
        setSpeakers(roster);
        setDrafts({});
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }, [bridge, videoId, speakers, drafts]);

  return (
    <section className="feature-panel diarize-panel" aria-label="Diarize">
      <h2>Speaker Diarization</h2>
      <p className="assets-intro">
        Label who speaks when — token-free, fully local. Needs a transcript first; the SpeechBrain
        models install on demand from the Assets tab.
      </p>

      <div className="actions">
        <button type="button" data-action="diarize" onClick={() => void run()} disabled={busy}>
          {busy ? 'Diarizing…' : 'Label speakers'}
        </button>
        {busy && jobId && (
          <button
            type="button"
            data-action="cancel"
            className="secondary"
            onClick={() => void cancel()}
          >
            Cancel
          </button>
        )}
      </div>

      {busy && (
        <div className="progress" aria-live="polite">
          <progress max={100} value={pct} />
          <span className="progress-pct">{Math.round(pct)}%</span>
          {message && <span className="progress-message"> · {message}</span>}
        </div>
      )}

      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}

      {speakers.length > 0 && (
        <>
          <h3>Speakers found ({speakers.length})</h3>
          <ul className="speaker-list" data-section="speakers">
            {speakers.map((speaker) => (
              <li key={speaker} className="speaker-row" data-speaker={speaker}>
                {speaker}
              </li>
            ))}
          </ul>

          <h3>Rename speakers</h3>
          <div className="rename-block" data-section="rename">
            {speakers.map((speaker) => (
              <label key={speaker} className="rename-row">
                <span className="rename-label">{speaker}</span>
                <input
                  type="text"
                  data-rename-for={speaker}
                  placeholder={speaker}
                  value={drafts[speaker] ?? ''}
                  onChange={(e) => setDrafts((prev) => ({ ...prev, [speaker]: e.target.value }))}
                />
              </label>
            ))}
            <button
              type="button"
              data-action="rename"
              className="secondary"
              onClick={() => void applyRename()}
            >
              Apply names
            </button>
          </div>
        </>
      )}
    </section>
  );
}

export default Diarize;
