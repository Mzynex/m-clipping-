// ShortMakerControls.test.tsx — behavioral tests for the pure presentational
// controls form. Mounts the component directly (react-dom/client + act under
// jsdom) and drives EVERY control handler + the submit/batch/cancel buttons and
// the audio-track option rendering, so each callback prop is exercised.

// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach, afterEach, type Mock } from 'vitest';
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';

import { ShortMakerControls } from './ShortMakerControls';
import {
  type AudioTrackOption,
  type ShortMakerControls as ShortMakerControlsState,
  DEFAULT_CONTROLS,
} from './shortMakerLogic';

const AUDIO_TRACKS: AudioTrackOption[] = [
  { id: 't-en', lang: 'en', name: 'English', kind: 'original' },
  { id: 't-es', lang: 'es', name: 'Spanish dub', kind: 'dub' },
];

interface Spies {
  setPrompt: Mock<(value: string) => void>;
  setControl: Mock<
    <K extends keyof ShortMakerControlsState>(key: K, value: ShortMakerControlsState[K]) => void
  >;
  setAudioTrackId: Mock<(value: string) => void>;
  applyPlatformPreset: Mock<(presetId: 'tiktok' | 'reels' | 'shorts') => void>;
  onSubmit: Mock<() => void>;
  onBatch: Mock<() => void>;
  onCancel: Mock<() => void>;
}

describe('<ShortMakerControls />', () => {
  let container: HTMLDivElement;
  let root: Root;
  let spies: Spies;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    root = createRoot(container);
    spies = {
      setPrompt: vi.fn<(value: string) => void>(),
      setControl:
        vi.fn<
          <K extends keyof ShortMakerControlsState>(
            key: K,
            value: ShortMakerControlsState[K],
          ) => void
        >(),
      setAudioTrackId: vi.fn<(value: string) => void>(),
      applyPlatformPreset: vi.fn<(presetId: 'tiktok' | 'reels' | 'shorts') => void>(),
      onSubmit: vi.fn<() => void>(),
      onBatch: vi.fn<() => void>(),
      onCancel: vi.fn<() => void>(),
    };
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  function mount(
    over: {
      controls?: Partial<ShortMakerControlsState>;
      busy?: boolean;
      hasCandidates?: boolean;
      audioTracks?: AudioTrackOption[];
      audioTrackId?: string;
      videoId?: string;
      prompt?: string;
    } = {},
  ): void {
    const controls: ShortMakerControlsState = { ...DEFAULT_CONTROLS, ...over.controls };
    act(() => {
      root.render(
        <ShortMakerControls
          videoId={over.videoId ?? 'v1'}
          prompt={over.prompt ?? ''}
          controls={controls}
          audioTracks={over.audioTracks ?? AUDIO_TRACKS}
          audioTrackId={over.audioTrackId ?? ''}
          busy={over.busy ?? false}
          hasCandidates={over.hasCandidates ?? false}
          setPrompt={spies.setPrompt}
          setControl={spies.setControl}
          setAudioTrackId={spies.setAudioTrackId}
          applyPlatformPreset={spies.applyPlatformPreset}
          onSubmit={spies.onSubmit}
          onBatch={spies.onBatch}
          onCancel={spies.onCancel}
        />,
      );
    });
  }

  function byLabel(label: string): HTMLElement {
    return container.querySelector(`[aria-label="${label}"]`) as HTMLElement;
  }

  // Select elements drive React via the `change` event; text/number inputs and
  // textareas drive it via `input`. Use the native value setter so React's
  // controlled-input value tracker registers the change either way.
  function change(el: HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement, value: string) {
    const proto =
      el instanceof HTMLSelectElement
        ? HTMLSelectElement.prototype
        : el instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')!.set!;
    act(() => {
      setter.call(el, value);
      const type = el instanceof HTMLSelectElement ? 'change' : 'input';
      el.dispatchEvent(new Event(type, { bubbles: true }));
    });
  }

  // STRENGTHENED (not weakened) after adversarial review: this is the surface
  // where a dub is actually chosen to be muxed into an exported short, so the
  // dub option must carry the Article-50 wording and not only the raw kind.
  it('renders the audio-track picker with Original plus every track option', () => {
    mount();
    const select = byLabel('Audio track') as HTMLSelectElement;
    const opts = [...select.options].map((o) => `${o.value}:${o.textContent}`);
    expect(opts[0]).toBe(':Original');
    expect(opts[1]).toBe('t-en:English (en, original)');
    expect(opts[2]).toBe('t-es:Spanish dub (es, dub) — AI-generated audio');
  });

  it('warns that the AI marking is in-app only when an AI track is selected for export', () => {
    mount({ audioTrackId: 't-es' });
    const note = container.querySelector('[data-testid="sm-ai-audio-note"]');
    expect(note?.textContent).toContain('not written into the exported file');
  });

  it('shows no AI export note for the original track or for no selection', () => {
    mount({ audioTrackId: 't-en' });
    expect(container.querySelector('[data-testid="sm-ai-audio-note"]')).toBeNull();
    mount({ audioTrackId: '' });
    expect(container.querySelector('[data-testid="sm-ai-audio-note"]')).toBeNull();
  });

  it('forwards prompt edits to setPrompt', () => {
    mount();
    const textarea = byLabel('Prompt') as HTMLTextAreaElement;
    change(textarea, 'quotable moments');
    expect(spies.setPrompt).toHaveBeenCalledWith('quotable moments');
  });

  it('forwards every numeric/select/text control change to setControl with the parsed value', () => {
    mount();
    change(byLabel('Count') as HTMLInputElement, '8');
    expect(spies.setControl).toHaveBeenCalledWith('count', 8);

    change(byLabel('Min seconds') as HTMLInputElement, '25');
    expect(spies.setControl).toHaveBeenCalledWith('minSec', 25);

    change(byLabel('Max seconds') as HTMLInputElement, '55');
    expect(spies.setControl).toHaveBeenCalledWith('maxSec', 55);

    change(byLabel('Aspect') as HTMLSelectElement, '1:1');
    expect(spies.setControl).toHaveBeenCalledWith('aspect', '1:1');

    change(byLabel('Language') as HTMLInputElement, 'es');
    expect(spies.setControl).toHaveBeenCalledWith('language', 'es');

    change(byLabel('Caption style') as HTMLSelectElement, 'bold');
    expect(spies.setControl).toHaveBeenCalledWith('captionStyle', 'bold');

    change(byLabel('Reframe engine') as HTMLSelectElement, 'verthor');
    expect(spies.setControl).toHaveBeenCalledWith('reframeEngine', 'verthor');

    change(byLabel('Emphasis') as HTMLSelectElement, 'on');
    expect(spies.setControl).toHaveBeenCalledWith('emphasis', 'on');
  });

  it('forwards each toggle change to setControl with the checked bool', () => {
    mount();
    const toggle = (label: string) => byLabel(label) as HTMLInputElement;
    // V1 quality-defaults-ON (G-4): all four quality toggles start ON, so a
    // single click flips each OFF (the inverse of the pre-V1 OFF defaults).
    act(() => {
      toggle('Hook title').click(); // ON -> OFF
    });
    expect(spies.setControl).toHaveBeenCalledWith('hookTitle', false);
    act(() => toggle('Remove fillers').click()); // ON -> OFF
    expect(spies.setControl).toHaveBeenCalledWith('removeFillers', false);
    act(() => toggle('Auto zoom').click());
    expect(spies.setControl).toHaveBeenCalledWith('autoZoom', false);
    act(() => toggle('Trim silence').click());
    expect(spies.setControl).toHaveBeenCalledWith('silenceTrim', false);
    act(() => toggle('Stabilize').click());
    expect(spies.setControl).toHaveBeenCalledWith('stabilize', false);
    // WU SP2: the hook-card toggle flips like the rest.
    act(() => toggle('Hook card').click()); // ON -> OFF
    expect(spies.setControl).toHaveBeenCalledWith('hookCard', false);
  });

  it('forwards the hook-card top-N number change and disables it when the card is off', () => {
    mount();
    change(byLabel('Hook card top N') as HTMLInputElement, '3');
    expect(spies.setControl).toHaveBeenCalledWith('hookCardTopN', 3);
    // enabled while the card toggle is ON ...
    expect((byLabel('Hook card top N') as HTMLInputElement).disabled).toBe(false);
    // ... and disabled when the card is OFF.
    mount({ controls: { hookCard: false } });
    expect((byLabel('Hook card top N') as HTMLInputElement).disabled).toBe(true);
  });

  it('forwards audio-track selection to setAudioTrackId', () => {
    mount();
    change(byLabel('Audio track') as HTMLSelectElement, 't-es');
    expect(spies.setAudioTrackId).toHaveBeenCalledWith('t-es');
  });

  it('applies a platform preset on click', () => {
    mount();
    const reels = container.querySelector('[data-preset="reels"]') as HTMLButtonElement;
    act(() => reels.click());
    expect(spies.applyPlatformPreset).toHaveBeenCalledWith('reels');
  });

  it('fires onSubmit on form submit (preventing default) and onBatch on the batch button', () => {
    mount();
    const form = container.querySelector('form')!;
    act(() => {
      form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    });
    expect(spies.onSubmit).toHaveBeenCalled();

    act(() => (byLabel('Make N shorts') as HTMLButtonElement).click());
    expect(spies.onBatch).toHaveBeenCalled();
  });

  it('shows Find clips by default and Regenerate once candidates exist', () => {
    mount({ hasCandidates: false });
    expect(container.querySelector('button[type="submit"]')?.textContent).toBe('Find clips');
    mount({ hasCandidates: true });
    expect(container.querySelector('button[type="submit"]')?.textContent).toBe('Regenerate');
  });

  it('shows a Cancel button only while busy and fires onCancel when clicked', () => {
    mount({ busy: false });
    expect([...container.querySelectorAll('button')].find((b) => b.textContent === 'Cancel')).toBe(
      undefined,
    );
    mount({ busy: true });
    const cancel = [...container.querySelectorAll('button')].find(
      (b) => b.textContent === 'Cancel',
    ) as HTMLButtonElement;
    expect(cancel).toBeTruthy();
    act(() => cancel.click());
    expect(spies.onCancel).toHaveBeenCalled();
  });

  it('disables submit/batch when there is no videoId', () => {
    mount({ videoId: '' });
    expect((container.querySelector('button[type="submit"]') as HTMLButtonElement).disabled).toBe(
      true,
    );
    expect((byLabel('Make N shorts') as HTMLButtonElement).disabled).toBe(true);
  });
});
