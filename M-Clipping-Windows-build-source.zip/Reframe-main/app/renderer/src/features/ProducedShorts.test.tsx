// ProducedShorts.test.tsx — behavioral tests for the per-video produced-shorts
// gallery (presentational). Mounts directly (real Player + ShortClipActions
// under jsdom) and covers: the empty-list null render, the card grid (title
// fallbacks, virality + template chips), inline-play swap (thumb button -> the
// inline <video> Player), and every card-action callback.

// @vitest-environment jsdom
import { describe, it, expect, vi, beforeAll, beforeEach, afterEach, type Mock } from 'vitest';
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';

import { ProducedShorts } from './ProducedShorts';
import type { BestFrame, DoneEvent, ProgressEvent, ShortInfo } from '../lib/rpc';

/** A controllable `window.api` stub: drives the job done/progress channels. */
interface ApiStub {
  rpc: ReturnType<typeof vi.fn>;
  onProgress: ReturnType<typeof vi.fn>;
  onJobDone: ReturnType<typeof vi.fn>;
  /** Fire the `job.done` notification the component subscribed to. */
  fireDone: (ev: DoneEvent) => void;
  /** Fire a `job.progress` notification. */
  fireProgress: (ev: ProgressEvent) => void;
  /** True once the component unsubscribed from `job.done`. */
  doneUnsubscribed: () => boolean;
}

function installApi(over: { rpc?: ReturnType<typeof vi.fn> } = {}): ApiStub {
  const doneCbs = new Set<(ev: DoneEvent) => void>();
  const progressCbs = new Set<(ev: ProgressEvent) => void>();
  const rpc = over.rpc ?? vi.fn(async () => ({ jobId: 'job-1' }));
  const onJobDone = vi.fn((cb: (ev: DoneEvent) => void) => {
    doneCbs.add(cb);
    return () => doneCbs.delete(cb);
  });
  const onProgress = vi.fn((cb: (ev: ProgressEvent) => void) => {
    progressCbs.add(cb);
    return () => progressCbs.delete(cb);
  });
  const api = { rpc, onProgress, onJobDone };
  (globalThis as unknown as { api?: unknown }).api = api;
  return {
    rpc,
    onProgress,
    onJobDone,
    fireDone: (ev) => act(() => doneCbs.forEach((cb) => cb(ev))),
    fireProgress: (ev) => act(() => progressCbs.forEach((cb) => cb(ev))),
    doneUnsubscribed: () => doneCbs.size === 0,
  };
}

function bestFrame(over: Partial<BestFrame> = {}): BestFrame {
  return {
    frameTimeSec: 7,
    thumbnailPath: '/out/clip-1.thumb.jpg',
    score: 0.91,
    degraded: false,
    ...over,
  };
}

beforeAll(() => {
  Object.defineProperty(HTMLMediaElement.prototype, 'play', {
    configurable: true,
    value: vi.fn(() => Promise.resolve()),
  });
  Object.defineProperty(HTMLMediaElement.prototype, 'pause', {
    configurable: true,
    value: vi.fn(),
  });
});

function short(over: Partial<ShortInfo> = {}): ShortInfo {
  return {
    id: 'sid-1',
    path: '/out/clip-1.mp4',
    videoId: 'v1',
    sourceTitle: 'My talk',
    template: 'hormozi',
    viralityPct: 73,
    durationSec: 30,
    width: 1080,
    height: 1920,
    createdAt: 1700000000,
    thumbnailPath: '',
    hook: 'A hook',
    ...over,
  };
}

describe('<ProducedShorts />', () => {
  let container: HTMLDivElement;
  let root: Root;
  let s: {
    onPlay: Mock<(path: string) => void>;
    onOpenFolder: Mock<(path: string) => void>;
    onReexport: Mock<(path: string) => void>;
    onDelete: Mock<(path: string) => void>;
  };

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    root = createRoot(container);
    s = {
      onPlay: vi.fn<(path: string) => void>(),
      onOpenFolder: vi.fn<(path: string) => void>(),
      onReexport: vi.fn<(path: string) => void>(),
      onDelete: vi.fn<(path: string) => void>(),
    };
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
    delete (globalThis as unknown as { api?: unknown }).api;
  });

  function mount(shorts: ShortInfo[], playingShortPath = '') {
    act(() => {
      root.render(
        <ProducedShorts
          shorts={shorts}
          playingShortPath={playingShortPath}
          onPlay={s.onPlay}
          onOpenFolder={s.onOpenFolder}
          onReexport={s.onReexport}
          onDelete={s.onDelete}
        />,
      );
    });
  }

  it('renders nothing for an empty list', () => {
    mount([]);
    expect(container.querySelector('.sm-video-shorts')).toBeNull();
  });

  it('renders a card per short with virality + template chips', () => {
    mount([short(), short({ id: 'sid-2', path: '/out/clip-2.mp4' })]);
    const cards = container.querySelectorAll('.shorts__card');
    expect(cards.length).toBe(2);
    expect(container.querySelector('.shorts__virality')?.textContent).toContain('73');
    expect(container.querySelector('.shorts__template')?.textContent).toBe('hormozi');
  });

  it('omits the virality + template chips when those fields are absent', () => {
    mount([short({ viralityPct: null, template: '' })]);
    expect(container.querySelector('.shorts__virality')).toBeNull();
    expect(container.querySelector('.shorts__template')).toBeNull();
  });

  it('falls back from sourceTitle to hook to path for the thumb label', () => {
    mount([short({ sourceTitle: '', hook: 'Hook only' })]);
    expect(container.querySelector('[aria-label="Play preview of Hook only"]')).toBeTruthy();
    mount([short({ sourceTitle: '', hook: '' })]);
    expect(container.querySelector('[aria-label="Play preview of /out/clip-1.mp4"]')).toBeTruthy();
  });

  it('clicking the thumb preview button fires onPlay with the path', () => {
    mount([short()]);
    const thumb = container.querySelector('.shorts__thumb-btn') as HTMLButtonElement;
    act(() => thumb.click());
    expect(s.onPlay).toHaveBeenCalledWith('/out/clip-1.mp4');
  });

  it('swaps the thumb button for an inline <video> Player when this clip is playing', () => {
    mount([short()], '/out/clip-1.mp4');
    expect(container.querySelector('.shorts__thumb-btn')).toBeNull();
    expect(container.querySelector('.shorts__player')).toBeTruthy();
    expect(container.querySelector('video')).toBeTruthy();
  });

  it('forwards each action-row button to its callback', () => {
    mount([short()]);
    const click = (label: string) =>
      act(() => (container.querySelector(`[aria-label="${label}"]`) as HTMLButtonElement).click());
    click('Open folder for My talk');
    expect(s.onOpenFolder).toHaveBeenCalledWith('/out/clip-1.mp4');
    click('Re-export My talk');
    expect(s.onReexport).toHaveBeenCalledWith('/out/clip-1.mp4');
    click('Delete My talk');
    expect(s.onDelete).toHaveBeenCalledWith('/out/clip-1.mp4');
    click('Play My talk');
    expect(s.onPlay).toHaveBeenCalledWith('/out/clip-1.mp4');
  });

  it('renders no Re-export control when onReexport is omitted', () => {
    // A host that wires no cross-view navigation (e.g. the Workspace mount)
    // leaves onReexport off; the action row must then show no dead Re-export
    // button while the other controls stay present.
    act(() => {
      root.render(
        <ProducedShorts
          shorts={[short()]}
          playingShortPath=""
          onPlay={s.onPlay}
          onOpenFolder={s.onOpenFolder}
          onDelete={s.onDelete}
        />,
      );
    });
    expect(container.querySelector('[aria-label="Re-export My talk"]')).toBeNull();
    expect(container.querySelector('[aria-label="Open folder for My talk"]')).toBeTruthy();
    expect(container.querySelector('[aria-label="Delete My talk"]')).toBeTruthy();
  });

  // ---- WU R5: virality-score CARD DASHBOARD (badge + duration + sort) ------

  const cardIds = () =>
    [...container.querySelectorAll('.shorts__card')].map((el) => el.getAttribute('data-id'));

  it('clamps the virality badge to a 0-100 int (displayVirality, AC badge)', () => {
    mount([short({ viralityPct: 150 })]);
    expect(container.querySelector('.shorts__virality')?.textContent).toContain('100');
    mount([short({ viralityPct: 73.6 })]);
    expect(container.querySelector('.shorts__virality')?.textContent).toContain('74');
  });

  it('omits the virality badge for a non-finite score (NaN)', () => {
    mount([short({ viralityPct: Number.NaN })]);
    expect(container.querySelector('.shorts__virality')).toBeNull();
  });

  it('renders the clip duration as mm:ss on each card (AC duration)', () => {
    mount([short({ durationSec: 95 })]);
    expect(container.querySelector('.shorts__thumb-duration')?.textContent).toBe('01:35');
    mount([short({ durationSec: 0 })]);
    expect(container.querySelector('.shorts__thumb-duration')?.textContent).toBe('--:--');
  });

  it('hides the sort toggle for a single clip', () => {
    mount([short()]);
    expect(container.querySelector('.shorts__sort')).toBeNull();
  });

  it('shows the sort toggle for 2+ clips, defaulting to virality score (AC sort)', () => {
    mount([
      short({ id: 'a', path: '/out/a.mp4', viralityPct: 40 }),
      short({ id: 'b', path: '/out/b.mp4', viralityPct: 90 }),
    ]);
    const toggle = container.querySelector('.shorts__sort');
    expect(toggle).toBeTruthy();
    const buttons = [...toggle!.querySelectorAll('.shorts__sort-btn')].map((b) => b.textContent);
    expect(buttons).toEqual(['Virality score', 'Recent']);
    const active = toggle!.querySelector('.shorts__sort-btn.is-active');
    expect(active?.textContent).toBe('Virality score');
    expect(active?.getAttribute('aria-pressed')).toBe('true');
    // Best-scoring clip leads by default.
    expect(cardIds()).toEqual(['b', 'a']);
  });

  it('re-orders by recency when "Recent" is chosen, by score when "Virality score" is', () => {
    mount([
      short({ id: 'old-hi', path: '/out/old.mp4', viralityPct: 90, createdAt: 1 }),
      short({ id: 'new-lo', path: '/out/new.mp4', viralityPct: 40, createdAt: 2 }),
    ]);
    // Default: by score (high first).
    expect(cardIds()).toEqual(['old-hi', 'new-lo']);
    const btn = (label: string) =>
      [...container.querySelectorAll('.shorts__sort-btn')].find(
        (b) => b.textContent === label,
      ) as HTMLButtonElement;
    act(() => btn('Recent').click());
    expect(cardIds()).toEqual(['new-lo', 'old-hi']);
    expect(btn('Recent').getAttribute('aria-pressed')).toBe('true');
    act(() => btn('Virality score').click());
    expect(cardIds()).toEqual(['old-hi', 'new-lo']);
  });

  // ---- WU-C4: "Pick best frame" action + thumbnail swap -------------------

  const pickBtn = (title = 'My talk') =>
    container.querySelector(
      `[aria-label="Pick the best thumbnail frame for ${title}"]`,
    ) as HTMLButtonElement;

  it('renders a per-clip "Pick best frame" button with the title in its name (AC a)', () => {
    installApi();
    mount([short()]);
    expect(pickBtn()).toBeTruthy();
    expect(pickBtn().type).toBe('button');
    // Falls back through the same title chain as the play control.
    mount([short({ sourceTitle: '', hook: 'Hook only' })]);
    expect(pickBtn('Hook only')).toBeTruthy();
  });

  it('marks the button aria-busy + disabled while the job runs (AC running)', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    expect(pickBtn().getAttribute('aria-busy')).toBe('true');
    expect(pickBtn().disabled).toBe(true);
    // Server contract (WU-C3 handler): videoId is mandatory and the clip span
    // must be a real, non-degenerate range — a standalone produced clip's whole
    // duration (0..durationSec) is its valid frame window. Sending only {path}
    // (omitting videoId) raises "videoId (str) is required" server-side, and a
    // 0..0 span samples no frames. Both must be supplied.
    expect(api.rpc).toHaveBeenCalledWith('thumbnail.select', {
      videoId: 'v1',
      path: '/out/clip-1.mp4',
      start: 0,
      end: 30,
    });
  });

  it('announces progress in a polite live region while running', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    api.fireProgress({ jobId: 'job-1', pct: 42, message: 'Scoring frames…' });
    const live = container.querySelector('[aria-live="polite"]');
    expect(live?.textContent).toContain('Scoring frames…');
  });

  it('swaps the thumbnail img src+alt and announces the new frame time on done (AC b)', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    api.fireDone({ jobId: 'job-1', result: bestFrame({ frameTimeSec: 7 }) });
    const img = container.querySelector('.shorts__thumb-img') as HTMLImageElement;
    expect(img).toBeTruthy();
    expect(img.getAttribute('src')).toContain(encodeURIComponent('short:/out/clip-1.thumb.jpg'));
    expect(img.alt).toContain('0:07');
    const live = container.querySelector('[aria-live="polite"]');
    expect(live?.textContent).toContain('Thumbnail updated to the frame at 0:07');
    // Job complete -> control re-enabled and unsubscribed.
    expect(pickBtn().getAttribute('aria-busy')).toBe('false');
    expect(api.doneUnsubscribed()).toBe(true);
  });

  it('renders the visible + announced midpoint note on a degraded done (AC c)', async () => {
    const api = installApi();
    mount([short({ thumbnailPath: '/out/poster.jpg' })]);
    await act(async () => {
      pickBtn().click();
    });
    // The LITERAL degrade payload the sidecar emits (handlers/vision_ops.py:310,
    // pinned by sidecar/tests/test_handlers_thumbnail.py:151-166): no
    // `thumbnailPath`, because the writer never runs on that branch.
    api.fireDone({ jobId: 'job-1', result: { frameTimeSec: 5, score: 0, degraded: true } });
    // A degrade is a SUCCESS, not a failure — assert that FIRST so a regression
    // reports "a red alert rendered on the degrade path", not a selector miss.
    expect(container.querySelector('[role="alert"]')?.textContent ?? null).toBeNull();
    expect(
      container.querySelector('.shorts__degrade-note')?.textContent ??
        '<no .shorts__degrade-note rendered>',
    ).toContain('No vision model available — used the middle frame');
    const live = container.querySelector('[aria-live="polite"]');
    expect(live?.textContent).toContain('No vision model available — used the middle frame');
    // No file was written, so the poster must stay put AND its alt must not
    // claim a frame time the pixels do not show (pickedSec stays null).
    const img = container.querySelector('.shorts__thumb-img') as HTMLImageElement;
    expect(img.getAttribute('src')).toContain(encodeURIComponent('short:/out/poster.jpg'));
    expect(img.alt).toBe('Thumbnail for My talk');
    expect(pickBtn().getAttribute('aria-busy')).toBe('false');
  });

  it('surfaces the sidecar failure message from a job.done error payload', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    // jobs.py:808-811 `_finish_error` — the rpc START succeeded, the FAILURE
    // arrives on the job.done channel carrying the real message.
    api.fireDone({
      jobId: 'job-1',
      result: { error: { message: 'vision backend exploded', type: 'RuntimeError' } },
    });
    expect(container.querySelector('[role="alert"]')?.textContent).toContain(
      'vision backend exploded',
    );
    expect(pickBtn().getAttribute('aria-busy')).toBe('false');
    expect(api.doneUnsubscribed()).toBe(true);
  });

  it('treats a cancelled job as a clean finish, not an error', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    // jobs.py:793-796 `_finish_cancelled` emits a TERMINAL job.done carrying a
    // JobCancelled envelope; every other panel treats it as a clean finish.
    api.fireDone({
      jobId: 'job-1',
      result: { error: { message: 'cancelled', type: 'JobCancelled' } },
    });
    expect(container.querySelector('[role="alert"]')).toBeNull();
    expect(container.querySelector('.shorts__degrade-note')).toBeNull();
    expect(pickBtn().getAttribute('aria-busy')).toBe('false');
    expect((pickBtn() as HTMLButtonElement).disabled).toBe(false);
    expect(api.doneUnsubscribed()).toBe(true);
  });

  it('still fails loud for a scored payload that lost its thumbnailPath', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    // Numeric frameTimeSec but no path and NOT degraded: genuinely unrecognisable,
    // so the widened predicate must not silently accept it as a swap.
    api.fireDone({ jobId: 'job-1', result: { frameTimeSec: 5, score: 0.9 } });
    expect(container.querySelector('[role="alert"]')?.textContent).toContain('unreadable result');
    expect(container.querySelector('.shorts__thumb-img')).toBeNull();
  });

  it('surfaces a role="alert" when the job fails (AC error)', async () => {
    const rpc = vi.fn(async () => {
      throw new Error('vision backend exploded');
    });
    installApi({ rpc });
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    const alert = container.querySelector('[role="alert"]');
    expect(alert?.textContent).toContain('vision backend exploded');
    // Failure re-enables the control.
    expect(pickBtn().getAttribute('aria-busy')).toBe('false');
  });

  it('reports a non-Error rejection as a string', async () => {
    const rpc = vi.fn(async () => {
      throw 'plain string failure';
    });
    installApi({ rpc });
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    expect(container.querySelector('[role="alert"]')?.textContent).toContain(
      'plain string failure',
    );
  });

  it('ignores progress/done notifications for a different jobId', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    api.fireProgress({ jobId: 'other', pct: 99, message: 'not mine' });
    api.fireDone({ jobId: 'other', result: bestFrame() });
    // Still running: no swap, no note, button stays busy.
    expect(container.querySelector('.shorts__thumb-img')).toBeNull();
    expect(pickBtn().getAttribute('aria-busy')).toBe('true');
  });

  it('renders an existing poster thumbnail before any pick, then swaps on done', async () => {
    const api = installApi();
    mount([short({ thumbnailPath: '/out/clip-1.thumb.jpg' })]);
    const img0 = container.querySelector('.shorts__thumb-img') as HTMLImageElement;
    expect(img0.getAttribute('src')).toContain(encodeURIComponent('short:/out/clip-1.thumb.jpg'));
    await act(async () => {
      pickBtn().click();
    });
    api.fireDone({ jobId: 'job-1', result: bestFrame({ thumbnailPath: '/out/clip-1.thumb.jpg' }) });
    const img1 = container.querySelector('.shorts__thumb-img') as HTMLImageElement;
    expect(img1.alt).toContain('0:07');
  });

  it('does nothing when the rpc returns no jobId (no subscription)', async () => {
    const rpc = vi.fn(async () => ({}));
    const api = installApi({ rpc });
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    // No jobId -> we never subscribed to done; control returns to idle.
    expect(api.onJobDone).not.toHaveBeenCalled();
    expect(pickBtn().getAttribute('aria-busy')).toBe('false');
  });

  it('fails loud (role="alert") on a malformed done payload (AC b guard)', async () => {
    const api = installApi();
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    // Missing frameTimeSec/thumbnailPath -> unreadable result.
    api.fireDone({ jobId: 'job-1', result: { score: 1 } });
    expect(container.querySelector('[role="alert"]')?.textContent).toContain('unreadable result');
    expect(container.querySelector('.shorts__thumb-img')).toBeNull();
    expect(api.doneUnsubscribed()).toBe(true);
  });

  it('stays running when the bridge exposes no onJobDone channel', async () => {
    // A preload without the deferred-job hook: the job can't complete client-side.
    const rpc = vi.fn(async () => ({ jobId: 'job-1' }));
    (globalThis as unknown as { api?: unknown }).api = {
      rpc,
      onProgress: vi.fn(() => () => undefined),
      // onJobDone intentionally absent.
    };
    mount([short()]);
    await act(async () => {
      pickBtn().click();
    });
    expect(pickBtn().getAttribute('aria-busy')).toBe('true');
    expect(container.querySelector('.shorts__thumb-img')).toBeNull();
  });
});
