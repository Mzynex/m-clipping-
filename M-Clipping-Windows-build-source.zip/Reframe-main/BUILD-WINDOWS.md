# Build M Clipping for Windows

The Windows installer is built on a Windows x64 runner because the packaged app
includes Windows CPython runtimes and FFmpeg binaries.

## Easiest route: GitHub Actions

1. Push this project to a GitHub repository you control.
2. Open the repository's **Actions** tab.
3. Select **Build M Clipping for Windows**.
4. Select **Run workflow** and confirm.
5. Wait for the workflow to finish successfully.
6. Open the completed run and download the **M-Clipping-Windows-x64** artifact.
7. Extract the downloaded artifact ZIP. Run the `M-Clipping-...-win-x64.exe`
   file to install M Clipping. The other ZIP is the portable build.

The workflow is manual (`workflow_dispatch`) and also runs when a `v*` tag is
pushed. It uploads build artifacts to the workflow run; it does not publish a
public GitHub Release or sign the installer with an EV/Authenticode certificate.
Windows SmartScreen may therefore show its normal unsigned-app warning.

## Build locally on Windows

Install Node.js 22, then open PowerShell in the repository root and run:

```powershell
./build/build-m-clipping.ps1
```

The installer and portable ZIP are written to `dist/`.
